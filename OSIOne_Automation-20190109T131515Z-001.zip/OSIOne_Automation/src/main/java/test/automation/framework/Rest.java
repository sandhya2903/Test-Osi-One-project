package test.automation.framework;

import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public final class Rest {

    public static RequestSpecification request;
    public static Response response;
    public static ValidatableResponse validatableResponse;
}
