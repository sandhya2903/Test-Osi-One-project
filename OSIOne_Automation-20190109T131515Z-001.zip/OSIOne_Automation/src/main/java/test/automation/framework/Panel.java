package test.automation.framework;

import ru.yandex.qatools.htmlelements.element.HtmlElement;

public abstract class Panel extends HtmlElement { }
