package test.automation.steps.OsiOne;

import cucumber.api.PendingException;
import cucumber.api.java.en.When;
import test.automation.framework.Page;
import test.automation.pages.OsiOne.LoginPage;
import test.automation.utils.UserUtils;

import static test.automation.framework.Runner.log;

public class LoginSteps extends Page {

    private LoginPage loginPage = new LoginPage();
    private UserUtils userUtils = new UserUtils();

    @When("^I enter login crdentials$")
    public void iEnterLoginCredentials() throws Throwable {
        loginPage.signIn(userUtils.getValidUser("Registered"));
        log().info("Logged into application");
    }


    @When("^I enter login credentials as RM$")
    public void iEnterLoginCredentialsAsRM() throws Throwable {
        loginPage.signIn(userUtils.getValidUser("RM"));
        log().info("RM Logged into application");
    }
}
