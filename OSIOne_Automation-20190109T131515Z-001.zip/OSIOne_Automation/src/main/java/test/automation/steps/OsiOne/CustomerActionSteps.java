package test.automation.steps.OsiOne;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import test.automation.framework.Actions;
import test.automation.framework.Page;
import test.automation.models.Customers;
import test.automation.pages.OsiOne.*;
import test.automation.utils.OsiOneData;
import test.automation.utils.UserUtils;

import java.util.List;
import java.util.stream.Collectors;

import static test.automation.framework.Runner.log;
import static test.automation.pages.OsiOne.AddCustomerPage.*;

public class CustomerActionSteps extends Page {

    public static String existingCustomerName;

    private CustomerPage customerPage = new CustomerPage();
    private AddCustomerPage addCustomerPage = new AddCustomerPage();
    private UserUtils userUtils = new UserUtils();
    private EditCustomerPage editCustomerPage = new EditCustomerPage();
    private HomePage homePage = new HomePage();
    private TimeSheetsSubmissionPage timeSheetsSubmissionPage = new TimeSheetsSubmissionPage();
    private NewLeaveRequestPage newRequestPage = new NewLeaveRequestPage();
    private EmpProfilePage empProfilePage = new EmpProfilePage();

    public static Customers customerDetails;
    public static Customers invoiceDetails;
    public static Customers commDetails;
    public static Customers contactDetails;
    public static Customers customerEditDetails;
    public static Customers invoiceEditDetails;
    public static Customers commEditDetails;
    public static Customers contactEditDetails;
    public static String[] Timesheetdate;
    public static String[] Monthwithdate;
    public static String Datevalue;
    public static String weekStartDateText;

    @And("^I enter valid customer details on add customer page$")
    public void iEnterValidCustomerDetailsOnAddCustomerPage() throws Throwable {
        customerDetails = userUtils.getCustomerDataInfo("CustomerDetails");
        invoiceDetails = userUtils.getCustomerDataInfo("InvoiceAddress");
        commDetails = userUtils.getCustomerDataInfo("CommunicationAddress");
        contactDetails = userUtils.getCustomerDataInfo("ContactPersonDetails");

        addCustomerPage.addCustomerDetails(customerDetails);
        addCustomerPage.addAdressDetails(invoiceDetails);
        addCustomerPage.addAdressDetails(commDetails);
        addCustomerPage.addContactsDetails(contactDetails);
        addCustomerPage.saveButton.click();
        Assert.assertTrue("Customers details are not saved successfully", addCustomerPage.customerSuccessMessage.isDisplayed());
    }

    @And("^I edit customer details from \"([^\"]*)\" page$")
    public void iEditCustomerDetailsFromPage(String pageName) throws Throwable {
        customerEditDetails = userUtils.getCustomerDataInfo("CustomerDetails");
        invoiceEditDetails = userUtils.getCustomerDataInfo("CommunicationAddress");
        commEditDetails = userUtils.getCustomerDataInfo("InvoiceAddress");
        contactEditDetails = userUtils.getCustomerDataInfo("ContactPersonDetails");

        onPage(pageName);
        editCustomerPage.editCustomerDetails(customerEditDetails);
        editCustomerPage.editInvoiceAdressDetails(invoiceEditDetails);
        editCustomerPage.editCommunicationAdressDetails(commEditDetails);
        editCustomerPage.editContactsDetails(contactEditDetails);
        editCustomerPage.saveBtn.click();
        Assert.assertTrue("Customers details are not saved successfully", editCustomerPage.customerSuccessMessage.isDisplayed());

    }

    @And("^I verify default values on create customer page$")
    public void iShouldSeeDefualtValuleOnCreateCustomerPage(List<String> values) throws Throwable {
        Assert.assertEquals("Invoice template option is not set to default option",
                addCustomerPage.invoiceTemplate.getFirstSelectedOption().getText(), values.get(0));
        Assert.assertEquals("Tax rate is showing other option than NOT APPLICABLE",
                addCustomerPage.taxRate.getFirstSelectedOption().getText(), values.get(1));
        //Assert.assertTrue("Active checkbox is not checked by default",
        //addCustomerPage.isActive.isSelected());
    }

    @When("^I search with newly created customer from \"([^\"]*)\" page$")
    public void iSearchWithNewlyCreatedCustomerFromCustomerPage(String pageName) throws Throwable {
        customerPage.searchWithLatestCreatedCustomerName(custName);
        log().info("searched with latest created customer" + custName);
    }

    @Then("^I should see the newly created customer records$")
    public void iShouldSeeTheNewlyCreatedCustomerReCord() throws Throwable {
        Assert.assertEquals("ERROR: Diffrent customer record found",
                custName, customerPage.getParticularCustomerNameFromResults(custName));
        log().info("searched with latest created customer" + custName);
    }

    @And("^I verify \"([^\"]*)\" customer details are correct$")
    public void iVerifyEnteredCustomerDetailsAreCorrect(String type) throws Throwable {
        Customers verifyCustomerDetails = type.equals("entered") ? customerDetails : customerEditDetails;
        Customers verifyInvoiceDetails = type.equals("entered") ? invoiceDetails : invoiceEditDetails;
        Customers verifyCommunicationDetails = type.equals("entered") ? commDetails : commEditDetails;
        Customers verifyContactDetails = type.equals("entered") ? contactDetails : contactEditDetails;

        WebElement record = customerPage.getParticularRowFromResults(custName);
//        Actions.execJavascript("arguments[0].scrollIntoView()", record);
        Thread.sleep(1000);
        Actions.doubleClick(record);
        editCustomerPage.verifyCustomerDetails(verifyCustomerDetails, type);
        editCustomerPage.verifyAddressDetails(verifyInvoiceDetails);
        editCustomerPage.verifyCommunicationDetails(verifyCommunicationDetails);
        editCustomerPage.verifyContactDetails(verifyContactDetails);
    }

    @And("^I search with existing customer name \"([^\"]*)\" on page$")
    public void iSearchWithExistingCustomerNameOnCustomerPage(String projectName) throws Throwable {
        existingCustomerName = projectName;
        Actions.execJavascript("arguments[0].scrollIntoView()", customerPage.customersSearch);
        Actions.execJavascript("arguments[0].click()", customerPage.customersSearch);
        customerPage.customersSearch.sendKeys(projectName);
        Actions.execJavascript("arguments[0].scrollIntoView()", customerPage.searchButton);
        Actions.execJavascript("arguments[0].click()", customerPage.searchButton);
        Actions.execJavascript("arguments[0].scrollIntoView()", customerPage.viewIcon);
        Actions.execJavascript("arguments[0].click()", customerPage.viewIcon);
    }

    @And("^I should see the existing customer details are in disabled mode on \"([^\"]*)\" page$")
    public void iShouldSeeTheExistingCustomerDetailsAreInDisabledMode(String pageName) throws Throwable {
        onPage(pageName);
        Assert.assertEquals("Existing customer name are not matched",
                AddCustomerPage.customerName.getText(), existingCustomerName);
        Assert.assertTrue("Customer long name should not be in disable mode",
                !AddCustomerPage.customerLongName.isEnabled());
        Assert.assertTrue("Website text box field should not be in disable mode ",
                !AddCustomerPage.website.isEnabled());
        Assert.assertTrue("Region dropdown field should not be in disable mode",
                !AddCustomerPage.region.isEnabled());
        Assert.assertTrue("Region dropdown field should not be in disable mode",
                !AddCustomerPage.timezone.isEnabled());
        Assert.assertTrue("Account Manager filed should not be in disable mode",
                !AddCustomerPage.accountManager.isEnabled());
        Assert.assertTrue("Sales Person Name filed should not be in disable mode",
                !AddCustomerPage.salesPersonName.isEnabled());
        Assert.assertTrue("Customer Sourced From filed should not be in disable mode",
                !AddCustomerPage.customerSourcedFrom.isEnabled());
        Assert.assertTrue("Payment Terms should not be in disable mode",
                !AddCustomerPage.paymentTerms.isEnabled());
        Assert.assertTrue("Invoice Notes should not be in disable mode",
                !AddCustomerPage.invoiceNotes.isEnabled());
        Assert.assertTrue("Invoice Template should not be in disable mode",
                !AddCustomerPage.invoiceTemplate.isEnabled());
        Assert.assertTrue("Tax Rate should not be in disable mode",
                !AddCustomerPage.taxRate.isEnabled());
        Assert.assertTrue("Late fee Terms should not be in disable mode",
                !AddCustomerPage.lateFeeTerms.isEnabled());
        Assert.assertTrue("Currency filed should not be in disable mode",
                !AddCustomerPage.currency.isEnabled());
        Assert.assertTrue("Business Domain field should not be in disable mode",
                !AddCustomerPage.businessDomain.isEnabled());
        Actions.waitUntil(() -> AddCustomerPage.editInvoiceAddress.isDisplayed());
        Actions.execJavascript("arguments[0].click()", AddCustomerPage.editInvoiceAddress);
//        AddCustomerPage.editInvoiceAddress.click();
        Assert.assertTrue("Invoice Address Radio Button should not be in disabled mode",
                AddCustomerPage.invoiceAddressLabelText.getAttribute("disabled").equals("true"));
        Assert.assertTrue("Primary Checkbox should not be in disabled mode",
                !AddCustomerPage.primaryCheckbox.isEnabled());
        Assert.assertTrue("Address Line1 should not be in disable mode",
                !AddCustomerPage.addressline1.isEnabled());
        Assert.assertTrue("Address Line2 should not be in disable mode",
                !AddCustomerPage.addressLine2.isEnabled());
        Assert.assertTrue("Country should not be in disable mode",
                !AddCustomerPage.country.isEnabled());
        Assert.assertTrue("State should not be in disable mode",
                !AddCustomerPage.state.isEnabled());
        Assert.assertTrue("City should not be in disable mode",
                !AddCustomerPage.city.isEnabled());
        Assert.assertTrue("Zipcode should not be in disable mode",
                !AddCustomerPage.zipcode.isEnabled());
        Actions.waitUntil(() -> AddCustomerPage.closeButton.isDisplayed());
        AddCustomerPage.closeButton.click();
        Actions.waitUntil(() -> !closeButton.isDisplayed(), 5000);
        Actions.execJavascript("arguments[0].click()", AddCustomerPage.editCommunicationAddress);
//        AddCustomerPage.editCommunicationAddress.click();
        Assert.assertTrue("Communication Address Radio button should not be in disabled mode",
                !AddCustomerPage.communicationAddressLabelText.isEnabled());
        Assert.assertTrue("Primary Checkbox should not be in disabled mode",
                !AddCustomerPage.primaryCheckbox.isEnabled());
        Actions.waitUntil(() -> addressline1.isDisplayed(), 3000);
        Assert.assertTrue("Address Line1 should not be in disable mode",
                !AddCustomerPage.addressline1.isEnabled());
        Assert.assertTrue("Address Line2 should not be in disable mode",
                !AddCustomerPage.addressLine2.isEnabled());
        Assert.assertTrue("Country should not be in disable mode",
                !AddCustomerPage.country.isEnabled());
        Assert.assertTrue("State should not be in disable mode",
                !AddCustomerPage.state.isEnabled());
        Assert.assertTrue("City should not be in disable mode",
                !AddCustomerPage.city.isEnabled());
        Assert.assertTrue("Zipcode should not be in disable mode",
                !AddCustomerPage.zipcode.isEnabled());
        Thread.sleep(200);
        Actions.execJavascript("arguments[0].click()", AddCustomerPage.closeButton);
        Actions.waitUntil(() -> !closeButton.isDisplayed(), 5000);
        AddCustomerPage.contacts.click();
        Actions.execJavascript("arguments[0].scrollIntoView();", editContactDetails);
        Actions.execJavascript("arguments[0].click();", editContactDetails);
        Actions.waitUntil(() -> AddCustomerPage.contactNumber.isDisplayed(), 4000);
        Assert.assertTrue("Contact Name should not be in disable mode",
                !AddCustomerPage.addContactName.isEnabled());
        Assert.assertTrue("Contact Number should not be in disable mode",
                !AddCustomerPage.contactNumber.isEnabled());
        Assert.assertTrue("Email Address should not be in disable mode",
                !AddCustomerPage.emailAddress.isEnabled());
        Assert.assertTrue("Alernate Contact Number should not be in disable mode",
                !AddCustomerPage.alternateContactNumber.isEnabled());
        AddCustomerPage.contactsCloseButton.click();
        Actions.waitUntil(() -> !contactsCloseButton.isDisplayed(), 3000);
        EditCustomerPage.documentsTab.click();
        Actions.waitUntil(() -> EditCustomerPage.documentLabel.isDisplayed(), 3000);
        Assert.assertTrue("Upload Document should not be in disabled mode",
                !EditCustomerPage.uploadDocument.isEnabled());
    }

    @Then("^I verify timesheet creation and click on \"([^\"]*)\" button$")
    public void iVerifyTimesheetCreationAndClickOnButton(String button) throws Throwable {
        timeSheetsSubmissionPage.navigateToWeeklyTimeSheetsPage();
        timeSheetsSubmissionPage.addHours();
        if (button.equals("Save")) {
            timeSheetsSubmissionPage.date();
            timeSheetsSubmissionPage.saveTimesheets();
        } else if (button.equals("Submit")) {
            timeSheetsSubmissionPage.submitTimesheets();
            timeSheetsSubmissionPage.logoutPage();
        }
    }

    @And("^I select the overdue timesheet from My Timesheets dashboard$")
    public void iSelectTheOverdueTimesheetFromMyTimesheetsDashboard() throws Throwable {
        onPage(HomePage.class);
        homePage.myProfile.click();
        onPage(EmpProfilePage.class);
        Actions.execJavascript("arguments[0].click();", empProfilePage.dashboard);
        onPage(HomePage.class);
        List<WebElement> element = homePage.overdue.stream().filter(e -> e.getText().contains("21-May-18")).collect(Collectors.toList());
        onPage(HomePage.class);
        element.get(0).click();
        Thread.sleep(1000);
    }

    @And("^I delete the selected timesheet from DB$")
    public void iDeleteTheSelectedTimesheetFromDB() throws Throwable {
        OsiOneData.deleteTimesheet();
    }

    @Then("^I enter the total (\\d+) hours and submit$")
    public void iEnterTheTotalHoursAndSubmit(int arg0) throws Throwable {
        timeSheetsSubmissionPage.addHours();
        timeSheetsSubmissionPage.submitTimesheets();
    }

//    @Then("^I click on Add leave request button$")
//    public void iVerifyLeaveCreation() throws Throwable {
//        LeavesPage.performLeaveOperations();
//        onPage("OsiOne NewLeaveRequestPage");
//        newRequestPage.calendarStartDate();
//        newRequestPage.calendarEndDate();
//        newRequestPage.selectLeaveTypes();
//        newRequestPage.purposeLeaveReason(newRequestPage.leaveTypeId.getFirstSelectedOption().getText());
//        //newRequestPage.uploadFile();
//    }
//
//    @Then("^I click Approve/Reject button$")
//    public void iClickApproveRejectButton() throws Throwable {
//        LeaveApprovalsPage.leaveApproveReject(LeaveApprovalsPage.tableDataInfo);
//    }
//
//    @And("^I should see Leave Approved Success Message$")
//    public void iShouldSeeLeaveApprovedSuccessMessage() throws Throwable {
//        LeaveApprovalsPage.SuccessMessage();
//
//    }
//
//    @And("^I click on Reject Button on Leaves Summary Page$")
//    public void iClickOnRejectButtonOnLeavesSummaryPage() throws Throwable {
//        LeaveApprovalsPage.leaveRejectedOperations();
//    }
//
//    @Then("^I should see Leave Request Rejected Message$")
//    public void iShouldSeeLeaveRequestRejectedMessage() throws Throwable {
//        LeaveApprovalsPage.leaveRejectSuccessMessage();
//    }
//
//    @And("^I click Reject button$")
//    public void iClickRejectButton() throws Throwable {
//        List<WebElement> listInfo = LeaveApprovalsPage.tableDataInfo;
//        LeaveApprovalsPage.leaveRejectLinkButton(listInfo);
//    }
//
//    @And("^I click on save button in leave request page$")
//    public void iClickOnSaveButtonInLeaveRequestPage() throws Throwable {
//        newRequestPage.saveButtonOperation();
//
//    }
//
//    @Then("^I should see \"([^\"]*)\" status$")
//    public void iShouldSeeStatus(String arg0) throws Throwable {
//        newRequestPage.statusVerify(newRequestPage.tableData, arg0);
//
//    }
//
//    @When("^click on Save&Submit button$")
//    public void clickOnSaveSubmitButton() throws Throwable {
//        newRequestPage.getLeavesList(newRequestPage.tableData);
//    }
//
//    @And("^I click on cancel leave Button$")
//    public void iClickOnCancelLeaveButton() throws Throwable {
//        newRequestPage.cancelButtonOperation();
//
//    }
//
//    @When("^I double click on \"([^\"]*)\" status$")
//    public void iDoubleClickOnStatus(String status) throws Throwable {
//        newRequestPage.doubleClickOnStatus(newRequestPage.tableData, status);
//
//    }
//
//    @And("^I click on Cancel Request Button$")
//    public void iClickOnCancelRequestButton() throws Throwable {
//        LeaveApprovalsPage.cancelRequestOpetation();
//    }
//
//    @And("^I Cancel Leave Button on Edit Leave Request Page$")
//    public void iCancelLeaveButtonOnEditLeaveRequestPage() throws Throwable {
//        newRequestPage.employeeCancelLeaveOpetaion();
//    }
}
