package test.automation.steps.OsiOne;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.htmlelements.element.TypifiedElement;
import test.automation.framework.*;
import test.automation.pages.OsiOne.ProjectsListPage;
import test.automation.pages.OsiOne.ProjectsPage;

import java.util.ArrayList;
import java.util.List;

import static test.automation.framework.Elements.getElement;


/**
 * Created by amolleti on 9/7/2018.
 */
public class ProjectSteps extends Page {
    private ProjectsPage projectsPage = new ProjectsPage();
    private ProjectsListPage projectsListPage = new ProjectsListPage();
    private PageNavigationSteps pageNavigationSteps = new PageNavigationSteps();
    private Steps steps = new Steps();

    @When("^I navigate to create projects page$")
    public void iNavigateToCreateProjectsPage() throws Throwable {
        pageNavigationSteps.iVisitProjectsPage();
    }

    @And("^I enter project details on \"([^\"]*)\" page$")
    public void iEnterProjectDetailsOnPage(String Page) throws Throwable {
        onPage("OsiOne ProjectsListPage");
        Actions.waitUntilElementPresent(projectsListPage.addProject, 500);
        Actions.execJavascript("arguments[0].click();", projectsListPage.addProject);
        onPage(Page);
        projectsPage.iEnterDetailsOfProject();
        Actions.execJavascript("arguments[0].scrollIntoView();", projectsPage.saveButton);
        Actions.execJavascript("arguments[0].click();", projectsPage.saveButton);
    }


    @Then("^I should see below message on \"([^\"]*)\" tab$")
    public void iShouldSeeBelowMessageOnTab(String tab, List<String> message) throws Throwable {
        switch (tab) {
            case "projects":
                Assert.assertTrue("Error --: Invalid alert error message on projects page", projectsPage.message.getText().equals(message.get(0)));
                break;
            case "commercials":
                Assert.assertTrue("Error --: Invalid alert error message on projects page", projectsPage.comercialsSaveButton.isDisplayed());
                break;
            case "projectPlanTab":
                Assert.assertTrue("Error --: Invalid alert error message on projects page", projectsPage.projectPlanSavedMessage.getText().equals(message.get(0)));
                break;
        }

    }

    @And("^I search with  project name and i navigate to \"([^\"]*)\" page$")
    public void iSearchWithProjectNameAndINavigateToPage(String page) throws Throwable {
        onPage("OsiOne ProjectsListPage");
        projectsListPage.searchBar.sendKeys(projectsPage.projName);
        Actions.execJavascript("arguments[0].click();", projectsListPage.searchButton);
        Thread.sleep(1000);
        Actions.doubleClick(projectsListPage.projNameIndex);
        onPage(page);
    }

    @Then("^I should see the dates of project and \"([^\"]*)\" must be match$")
    public void iShouldSeeTheDatesOfProjectAndMustBeMatch(String Tab) throws Throwable {
        switch (Tab) {
            case "commercial":
                Actions.execJavascript("arguments[0].click();", projectsPage.commericalTab);
                Assert.assertEquals(projectsPage.StartDate, projectsPage.sowStartDate.getAttribute("value"));
                Assert.assertEquals(projectsPage.EndDate, projectsPage.sowEndDate.getAttribute("value"));
                break;
            case "resources":
                Actions.execJavascript("arguments[0].click();", projectsPage.resourcesTab);
                Actions.execJavascript("arguments[0].click();", projectsPage.addResources);
                Assert.assertEquals(projectsPage.StartDate, projectsPage.sowStartDate.getAttribute("value"));
                Assert.assertEquals(projectsPage.EndDate, projectsPage.sowEndDate.getAttribute("value"));
                break;
            case "projectplan":
                Actions.execJavascript("arguments[0].click();", projectsPage.projectPlanTab);
                Actions.execJavascript("arguments[0].scrollIntoView()", projectsPage.actionsview);
                Assert.assertEquals(projectsPage.StartDate, projectsPage.ppStartDate.getAttribute("value"));
                Assert.assertEquals(projectsPage.EndDate, projectsPage.ppEndDate.getAttribute("value"));
                break;

        }
    }

    @Then("^I enter sow deatils for particular project$")
    public void iEnterSowDeatilsForParticularProject() throws Throwable {
        Actions.execJavascript("arguments[0].click();", projectsPage.commericalTab);
        projectsPage.sowDetails();
    }

    @Then("^I enter multiple activities for particular project$")
    public void iEnterMultipleActivitiesForParticularProject() throws Throwable {
        Actions.execJavascript("arguments[0].click();", projectsPage.commericalTab);
        projectsPage.multipleActivities();
    }

    @And("^I should see the total activities count and role count on add resources popup must be same$")
    public void iShouldSeeTheTotalActivitiesCountAndRoleCountOnAddResourcesPopupMustBeSame() throws Throwable {
        Actions.execJavascript("arguments[0].click();", projectsPage.resourcesTab);
        Actions.execJavascript("arguments[0].click();", projectsPage.addResources);
        Assert.assertEquals(projectsPage.ActivityNames.size() - 1, projectsPage.emprolelist.size() - 1);

    }

    @Then("^I enter resource details for particular project$")
    public void iEnterResourceDetailsForParticularProject() throws Throwable {
        iEnterSowDeatilsForParticularProject();
        projectsPage.addResources();
    }

    @And("^I should see the resource deatils on resource dashbord$")
    public void iShouldSeeTheResourceDeatilsOnResourceDashbord() throws Throwable {
//        projectsPage.TableData(projectsPage.resourceTable);
        Assert.assertTrue(projectsPage.EmployeName.contains(projectsPage.resourceName.getText()));
        Assert.assertTrue(projectsPage.EmployeRole.contains(projectsPage.resourceRole.getText().substring(5)));
    }

    @Then("^I should edit the existing project details$")
    public void iShouldEditTheExistingProjectDetails() throws Throwable {
        projectsPage.iEditDetailsOfProject();
        Thread.sleep(1000);
        Actions.execJavascript("arguments[0].scrollIntoView();", projectsPage.saveButton);
        Actions.execJavascript("arguments[0].click();", projectsPage.saveButton);
    }

    @And("^I should see whether the edit details are persisted in the project$")
    public void iShouldSeeWhetherTheEditDetailsArePersistedInTheProject() throws Throwable {
//        onPage("OsiOne ProjectsListPage");
//        projectsListPage.searchBar.sendKeys(projectsPage.projName);
//        Actions.execJavascript("arguments[0].click();", projectsListPage.searchButton);
        Thread.sleep(500);
        projectsPage.verifyEditDetails();

    }

    @Then("^I should see following elements under \"([^\"]*)\" tab$")
    public void iShouldSeeFollowingElementsUnderTab(String Tab, List<String> elements) throws Throwable {
        TypifiedElement element = getElement(Tab);
        Actions.execJavascript("arguments[0].click();", element);
        steps.iShouldSeeFollowingElements(elements);
    }

    @And("^I should see the activities list in projectplan tab$")
    public void iShouldSeeTheActivitiesListInProjectplanTable() throws Throwable {
        Actions.execJavascript("arguments[0].click();", projectsPage.projectPlanTab);
        Assert.assertTrue("", projectsPage.nameListEquals(projectsPage.ActivitiesList, projectsPage.TaskNames));
    }

    @Then("^I should see the added resource in assigned resources on projectplan$")
    public void iShouldSeeTheAddedResourceInAssignedResourcesOnProjectplan() throws Throwable {
        Actions.execJavascript("arguments[0].click();", projectsPage.projectPlanTab);
        Actions.execJavascript("arguments[0].click();", projectsPage.assignedResourceview);
        Assert.assertTrue(projectsPage.EmployeName.replaceAll("\\s+$", "").equals(projectsPage.assignedResourceName.getText()));
    }

    @Then("^I should delete the details from \"([^\"]*)\" tab$")
    public void iShouldDeleteTheDetailsFromTab(String arg0) throws Throwable {
        projectsPage.resourceName.click();
        Actions.execJavascript("arguments[0].click();", projectsPage.resourceDelete);
        Actions.waitUntilElementPresent((TypifiedElement) projectsPage.resourceDeletePopup, 500);
        Assert.assertTrue("Confirmation popup is not displaying ", "Confirmation".equals(projectsPage.resourceDeletePopup.getText()));
        Thread.sleep(500);
        Actions.execJavascript("arguments[0].click();", projectsPage.resourceDeleteConfirmation);
        Thread.sleep(500);
        Assert.assertTrue("Records are still exists in resources", "No Records Found".equals(projectsPage.noRecordsFound.getText()));
    }

    @Then("^I enter project plan details for particular project$")
    public void iEnterProjectPlanDetailsForParticularProject() throws Throwable {
        iEnterResourceDetailsForParticularProject();
        Actions.execJavascript("arguments[0].click();", projectsPage.projectPlanTab);
        projectsPage.projectPlanDetails();
    }
}
