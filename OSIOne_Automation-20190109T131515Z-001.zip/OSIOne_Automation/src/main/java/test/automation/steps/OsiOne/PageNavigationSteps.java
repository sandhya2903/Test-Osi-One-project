package test.automation.steps.OsiOne;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import test.automation.framework.Actions;
import test.automation.framework.Page;
import test.automation.pages.OsiOne.*;
import test.automation.utils.UserUtils;

public class PageNavigationSteps extends Page {

    private LoginPage loginPage = new LoginPage();
    private HomePage homePage = new HomePage();
    private CustomerPage customerPage = new CustomerPage();
    private UserUtils userUtils = new UserUtils();
    private ExpensesPage expensesPage = new ExpensesPage();

    @When("^I navigate to create customer page$")
    public void iVisitCreateCustomerPage() throws Throwable {
        Actions.waitUntilElementPresent(LoginPage.loginButton);
        loginPage.signIn(userUtils.getValidUser("Registered"));
        onPage("OsiOne HomePage");
        homePage.navigateToCustomerPage();
        onPage("OsiOne CustomerPage");
    }

    @When("^I navigate to projects page$")
    public void iVisitProjectsPage() throws Throwable {
        Actions.waitUntilElementPresent(LoginPage.loginButton);
        loginPage.signIn(userUtils.getValidUser("Registered"));
        onPage("OsiOne HomePage");
        homePage.navigateToProjectsPage();
        onPage("OsiOne ProjectsListPage");
    }

    @When("^I navigate to expenses page$")
    public void iNavigateToExpensesPage() throws Throwable {
        Actions.waitUntilElementPresent(LoginPage.loginButton);
        loginPage.signIn(userUtils.getValidUser("Registered"));
        onPage("OsiOne HomePage");
        homePage.navigateToExpensesPage();
        onPage("OsiOne ExpensesPage");
    }

    @When("^I select Add Customer using \"([^\"]*)\" button from customer page$")
    public void iSelectAddCustomerOnCustomerPage(String selectedOption) throws Throwable {
        customerPage.selectAddCustomer(selectedOption);
    }

    @And("^I click on editIcon button on customer page$")
    public void iClickOnEditIconButtonOnCustomerPage() throws Throwable {
        customerPage.selectEditCustomerButton();
    }

    @And("^I click on documents tab and and click on Upload document button on edit customer page$")
    public void iClickOnDocumentsTabAndAndClickOnUploadDocumentButtonOnEditCustomerPage() throws Throwable {
        EditCustomerPage.btnClick();
    }


    @When("^I navigate to MyLeaves Page$")
    public void iNavigateToMyLeavesPage() throws Throwable {
        Thread.sleep(500);
        loginPage.signIn(userUtils.getValidUser("Registered"));
        onPage("OsiOne HomePage");
        homePage.navigateToLeavesPage();
        onPage("OsiOne LeavesPage");
    }

    @When("^I navigate to LeavesApproval Page$")
    public void iNavigateToLeavesApprovalPage() throws Throwable {
        Thread.sleep(500);
        loginPage.signIn(userUtils.getValidUser("RM"));
        onPage("OsiOne HomePage");
        homePage.navigateToLeavesApprovalPage();
        onPage("OsiOne LeaveApprovalsPage");
        Thread.sleep(500);
    }

    @Then("^I add documents \"([^\"]*)\" file name in Add Document popup$")
    public void iAddDocumentsFileNameInAddDocumentPopup(String fileName) throws Throwable {
        EditCustomerPage.UploadDocuments(fileName);
    }

}
