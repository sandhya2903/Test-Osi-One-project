package test.automation.steps.OsiOne;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.htmlelements.element.TypifiedElement;
import test.automation.framework.Actions;
import test.automation.framework.Page;
import test.automation.pages.OsiOne.*;
import test.automation.utils.OsiOneData;
import test.automation.utils.UserUtils;

import java.util.List;
import java.util.stream.Collectors;

import static test.automation.framework.Elements.getElement;

/**
 * Created by amolleti on 9/25/2018.
 */
public class ExpensesSteps extends Page {
    private ProjectsPage projectsPage = new ProjectsPage();
    private CreateExpensesPage createExpenses = new CreateExpensesPage();
    private ViewExpenses viewExpenses = new ViewExpenses();
    private LoginPage loginPage = new LoginPage();
    private LogoutPage logoutPage = new LogoutPage();
    private HomePage homePage = new HomePage();
    private CustomerPage customerPage = new CustomerPage();
    private UserUtils userUtils = new UserUtils();
    private ExpensesPage expensesPage = new ExpensesPage();
    private ManagerExpensePage managerExpensePage = new ManagerExpensePage();
    private ManagerApprovePage managerApprovePage = new ManagerApprovePage();

    @And("^I enter expenses details and (save|submmit) on \"([^\"]*)\" page$")
    public void iEnterExpensesDetailsAndSaveOnPage(String button, String page) throws Throwable {
        createExpenses.addExpensesDetails();
        createExpenses.TableData(createExpenses.createExpensesReport);
        createExpenses.saveExpenses.click();
        if (button.equals("save")) {
            createExpenses.saveButtonExpenses.click();
        } else if (button.equals("submmit")) {
            createExpenses.submitButtonExpenses.click();
        }
    }

    @Then("^I should see below message on confirmation popup and click on \"([^\"]*)\" button$")
    public void iShouldSeeBelowMessageOnConfirmationPopupAndClickOnButton(String element0, List<String> element) throws Throwable {
        Actions.waitUntilElementPresent(createExpenses.confirmatonMessage);
        onPage(CreateExpensesPage.class);
        Assert.assertTrue("Popup is not displaying", element.get(0).equals(createExpenses.confirmatonMessage.getText()));
        if (element0.equals("Yes"))
            createExpenses.expensesSubmitConfirmation.click();
    }

    @Then("^I should see below message in confirmation popup on \"([^\"]*)\" page and click on \"([^\"]*)\" button$")
    public void iShouldSeeBelowMessageInConfirmationPopupOnPageAndClickOnButton(String page, String element0, List<String> element) throws Throwable {
        if (page.equals("OsiOne CreateExpensesPage")) {
            Actions.waitUntilElementPresent(createExpenses.confirmatonMessage);
            onPage(CreateExpensesPage.class);
            Assert.assertTrue("Popup is not displaying", element.get(0).equals(createExpenses.confirmatonMessage.getText()));
            if (element0.equals("Yes"))
                createExpenses.expensesSubmitConfirmation.click();
        } else if (page.equals("OsiOne ManagerApprovePage") && element0.equals("Yes")) {
            Actions.waitUntilElementPresent(managerApprovePage.confirmationMessage);
            onPage(ManagerApprovePage.class);
            Assert.assertTrue("Popup is not displaying", element.get(0).equals(managerApprovePage.confirmationMessage.getText()));
            if (element0.equals("Yes"))
                managerApprovePage.approveSubmitConfirmation.click();
        }else if(page.equals("OsiOne ManagerApprovePage") && element0.equals("Submit")){
            onPage(ManagerApprovePage.class);
            managerApprovePage.rejectReason.sendKeys("Not Valid");
            managerApprovePage.submit.click();
        }
    }

    @Then("^I verify the status of expenses report should be \"([^\"]*)\"$")
    public void iVerifyTheStatusOfExpensesReportShouldBe(String status) throws Throwable {
        if (status.equals("Submitted")) {
            ViewExpenses.submitted.click();
            Actions.waitUntilElementPresent(viewExpenses.createdDate);
//            Assert.assertTrue("", viewExpenses.createdDate.getText().equals(createExpenses.AddExpenseDate));
            homePage.toggleButton.click();
            Assert.assertTrue("Status of expenses report is not in" + status + "state", viewExpenses.status.getText().equals(status));
        } else if (status.equals("Open")) {
            Actions.waitUntilElementPresent(viewExpenses.createdDate);
//            Assert.assertTrue("", viewExpenses.createdDate.getText().equals(createExpenses.AddExpenseDate));
            homePage.toggleButton.click();
            Assert.assertTrue("Status of expenses report is not in" + status + "state", viewExpenses.status.getText().equals(status));
        } else if (status.equals("Approved")) {
            onPage(ManagerExpensePage.class);
            managerExpensePage.logout.click();
            onPage(LogoutPage.class);
            Thread.sleep(500);
            logoutPage.signIn(userUtils.getValidUser("Registered"));
            onPage("OsiOne HomePage");
            homePage.navigateToExpensesPage();
            viewExpenses.approved.click();
            homePage.toggleButton.click();
            Assert.assertTrue("Status of expenses report is not in" + status + "state", viewExpenses.status.getText().equals(status));
        }else if(status.equals("Rejected")){
            onPage(ManagerExpensePage.class);
            Actions.execJavascript("arguments[0].click();",managerExpensePage.logout);
//            managerExpensePage.logout.click();
            Thread.sleep(500);
            onPage(LogoutPage.class);
            Thread.sleep(500);
            logoutPage.signIn(userUtils.getValidUser("Registered"));
            onPage("OsiOne HomePage");
            homePage.navigateToExpensesPage();
            viewExpenses.rejected.click();
            homePage.toggleButton.click();
            Assert.assertTrue("Status of expenses report is not in" + status + "state", viewExpenses.status.getText().equals(status));
        }
    }

    @And("^I login with \"([^\"]*)\" credentials$")
    public void iLoginWithCredentials(String level) throws Throwable {
        if (level.equals("Approver1")) {
            onPage(ViewExpenses.class);
            viewExpenses.logout.click();
        } else if (level.equals("Approver2")) {
            onPage(ManagerExpensePage.class);
            managerExpensePage.logout.click();
        }
        onPage(LogoutPage.class);
        Thread.sleep(500);
        logoutPage.signIn(userUtils.getValidUser(level));
        onPage("OsiOne HomePage");
        homePage.navigateToExpensesApprovalPage();
    }

    @Then("^I aprrove the expense from approve end$")
    public void iAprroveTheExpenseFromApproveEnd() throws Throwable {
        onPage(ManagerExpensePage.class);
        managerExpensePage.rowData.stream().filter(a -> a.getText().equals("Raju donepudi")).collect(Collectors.toList()).get(0).click();
    }

    @Then("^I \"([^\"]*)\" the expense from approver end$")
    public void iTheExpenseFromIntialApproveEnd(String button) throws Throwable {
        onPage(ManagerExpensePage.class);
        managerExpensePage.rowData.stream().filter(a -> a.getText().equals("Raju donepudi")).collect(Collectors.toList()).get(0).click();
        onPage(ManagerApprovePage.class);
        Actions.waitUntilElementPresent(managerApprovePage.approve);
        managerApprovePage.checkbox.click();
        TypifiedElement elementO = getElement(button);
        elementO.click();
    }


}
