package test.automation.steps.OsiOne;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebElement;
import test.automation.framework.Page;
import test.automation.pages.OsiOne.LeaveApprovalsPage;
import test.automation.pages.OsiOne.LeavesPage;
import test.automation.pages.OsiOne.NewLeaveRequestPage;

import java.util.List;

/**
 * Created by vemanepalli on 05-Oct-18.
 */
public class LeaveActionSteps  extends Page{

    NewLeaveRequestPage newRequestPage = new NewLeaveRequestPage();

    @Then("^I click on Add leave request button$")
    public void iVerifyLeaveCreation() throws Throwable {
        LeavesPage.performLeaveOperations();
        onPage("OsiOne NewLeaveRequestPage");
        newRequestPage.calendarStartDate();
        newRequestPage.calendarEndDate();
        newRequestPage.selectLeaveTypes();
        newRequestPage.purposeLeaveReason(newRequestPage.leaveTypeId.getFirstSelectedOption().getText());
        //newRequestPage.uploadFile();
    }

    @Then("^I click Approve/Reject button$")
    public void iClickApproveRejectButton() throws Throwable {
        LeaveApprovalsPage.leaveApproveReject(LeaveApprovalsPage.tableDataInfo);
    }

    @And("^I should see Leave Approved Success Message$")
    public void iShouldSeeLeaveApprovedSuccessMessage() throws Throwable {
        LeaveApprovalsPage.SuccessMessage();

    }

    @And("^I click on Reject Button on Leaves Summary Page$")
    public void iClickOnRejectButtonOnLeavesSummaryPage() throws Throwable {
        LeaveApprovalsPage.leaveRejectedOperations();
    }

    @Then("^I should see Leave Request Rejected Message$")
    public void iShouldSeeLeaveRequestRejectedMessage() throws Throwable {
        LeaveApprovalsPage.leaveRejectSuccessMessage();
    }

    @And("^I click Reject button$")
    public void iClickRejectButton() throws Throwable {
        List<WebElement> listInfo = LeaveApprovalsPage.tableDataInfo;
        LeaveApprovalsPage.leaveRejectLinkButton(listInfo);
    }

    @And("^I click on save button in leave request page$")
    public void iClickOnSaveButtonInLeaveRequestPage() throws Throwable {
        newRequestPage.saveButtonOperation();

    }

    @Then("^I should see \"([^\"]*)\" status$")
    public void iShouldSeeStatus(String arg0) throws Throwable {
        newRequestPage.statusVerify(newRequestPage.tableData, arg0);

    }

    @When("^click on Save&Submit button$")
    public void clickOnSaveSubmitButton() throws Throwable {
        newRequestPage.getLeavesList(newRequestPage.tableData);
    }

    @And("^I click on cancel leave Button$")
    public void iClickOnCancelLeaveButton() throws Throwable {
        newRequestPage.cancelButtonOperation();

    }

    @When("^I double click on \"([^\"]*)\" status$")
    public void iDoubleClickOnStatus(String status) throws Throwable {
        newRequestPage.doubleClickOnStatus(newRequestPage.tableData, status);

    }

    @And("^I click on Cancel Request Button$")
    public void iClickOnCancelRequestButton() throws Throwable {
        LeaveApprovalsPage.cancelRequestOpetation();
    }

    @And("^I Cancel Leave Button on Edit Leave Request Page$")
    public void iCancelLeaveButtonOnEditLeaveRequestPage() throws Throwable {
        newRequestPage.employeeCancelLeaveOpetaion();
    }
}
