package test.automation.steps.OsiOne;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import test.automation.framework.Page;
import test.automation.pages.OsiOne.HomePage;
import test.automation.pages.OsiOne.MyTimeSheetPage;
import test.automation.pages.OsiOne.TimeSheetApprovalListPage;
import test.automation.pages.OsiOne.TimeSheetsSubmissionPage;
import test.automation.utils.OsiOneData;

import java.util.*;
import java.util.stream.Collectors;


/**
 * Created by vemanepalli on 08-Oct-18.
 */
public class TimeSheetSteps extends Page {

    HomePage homePage = new HomePage();
    TimeSheetApprovalListPage timeSheetApproval = new TimeSheetApprovalListPage();
    TimeSheetsSubmissionPage timeSheetsSubmissionPage = new TimeSheetsSubmissionPage();
    MyTimeSheetPage myTimeSheetPage = new MyTimeSheetPage();

    @And("^I navigate to TimeSheetApprovalPage$")
    public void iNavigateToTimeSheetApprovalPage() throws Throwable {
        Thread.sleep(500);
        homePage.navigateToTimeSheets();
        onPage("OsiOne TimeSheetApprovalListPage");
    }

    @Then("^I Approved timesheet for employee$")
    public void iApprovedTimesheetForEmployee() throws Throwable {
        timeSheetApproval.timeSheetEmployeeData();
        timeSheetApproval.timesheetApprovedByRM();
    }

    @Then("^I Reject timesheet for employee$")
    public void iRejectTimesheetForEmployee() throws Throwable {
        timeSheetApproval.timeSheetEmployeeData();
        timeSheetApproval.timeSheetRejectedByRM();

    }

    @Then("^I should see \"([^\"]*)\" Status on dashboard$")
    public void iShouldSeeStatusOnDashboard(String arg0) throws Throwable {
        String[] Timesheetdate = timeSheetsSubmissionPage.weekStartDateText.split("\n");
        String[] Monthwithdate = Timesheetdate[1].split("-");
        String Datevalue = Monthwithdate[0] + "-" + Timesheetdate[0] + "-19";
        onPage(HomePage.class);
        List<WebElement> element = homePage.overdue.stream().filter(e -> e.getText().equals(arg0)).collect(Collectors.toList());
        Thread.sleep(2000);
        element.get(element.size() - 1).click();

    }

    @And("^I delete the selected dates from DB$")
    public void iDeleteTheSelectedDatesFromDB() throws Throwable {
        OsiOneData.deleteDashboradSheet();
    }

    @And("^I submit the rejected sheet on \"([^\"]*)\"$")
    public void iSubmitTheRejectedSheetOn(String page) throws Throwable {
        onPage(page);
        timeSheetsSubmissionPage.submitTimesheets();
    }

    @Then("^I should see \"([^\"]*)\" Status on dashboard page$")
    public void iShouldSeeStatusOnDashboardPage(String arg0) throws Throwable {
        //homePage.dashboard.click();
        Thread.sleep(2000);
        onPage(HomePage.class);
        List<WebElement> element = homePage.overdue.stream().filter(e -> e.getText().equals(arg0)).collect(Collectors.toList());
        Assert.assertTrue(" Saved report is not displaying in my timesheets block ", element.get(0).getText().equals("Saved"));
        OsiOneData.deleteSaveDates();

    }

    @And("^I navigate to my timesheets page$")
    public void iNavigateToMyTimesheetsPage() throws Throwable {
        onPage(TimeSheetsSubmissionPage.class);
        timeSheetsSubmissionPage.dashboard.click();
        onPage(HomePage.class);
        homePage.navigateMyTimeSheets();
    }

    @Then("^I select the date range \"([^\"]*)\" and \"([^\"]*)\" status from dropdowns$")
    public void iSelectTheDateRangeAndStatusFromDropdowns(String range0, String status) throws Throwable {
        onPage(MyTimeSheetPage.class);
        myTimeSheetPage.rangeselect.selectByVisibleText(range0);
        myTimeSheetPage.statusSelect.selectByVisibleText(status);
        myTimeSheetPage.TableData();
    }

    @And("^I should see the submitt status for \"([^\"]*)\"$")
    public void iShouldSeeTheSubmittStatusFor(String empName) throws Throwable {
        Assert.assertTrue("", myTimeSheetPage.userTable.get(0).get("Date").getText().equals("21 May 2018"));
        Assert.assertTrue("", myTimeSheetPage.userTable.get(0).get("Week").getText().equals("21 May 2018 - 27 May 2018"));
        Assert.assertTrue("", myTimeSheetPage.userTable.get(0).get("Employee Name").getText().equals(empName));
        Assert.assertTrue("", myTimeSheetPage.userTable.get(0).get("Status").getText().equals("Submitted"));
    }
}
