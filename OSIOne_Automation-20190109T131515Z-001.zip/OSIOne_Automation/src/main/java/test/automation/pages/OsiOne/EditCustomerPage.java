package test.automation.pages.OsiOne;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.*;
import ru.yandex.qatools.htmlelements.element.Button;
import test.automation.framework.*;
import test.automation.models.Customers;

import java.awt.*;
import java.util.stream.Collectors;

import static test.automation.pages.OsiOne.AddCustomerPage.*;


public class EditCustomerPage extends Page {

    public static final String URL = Config.getUrl() + "/a1/#/editCustomer";
    //public static final By VERIFY_BY = By.xpath("//a[contains(text(),'Edit Customer')]");
    public static final By VERIFY_BY = By.xpath("//*[@class='breadcrumb-item active ng-binding']");

    public static String custEditedName;

    @Name("Customers Page Navigation From Breadcrumb")
    @FindBy(xpath = "//a[contains(text(),'Customers')]")
    public static Link customersLinkBreadCrumb;

    @Name("Documents Tab")
    @FindBy(xpath = "//a[contains(text(),'Documents')]")
    public static Link documentsTab;

    @Name("Document Label")
    @FindBy(xpath = "//*[@ng-click=\"vm.openTab($event, 'attachments');\"]")
    public static WebElement documentLabel;

    @Name("Upload Document")
    @FindBy(xpath = "//button[contains(text(), 'Upload Document')]")
    public static Button uploadDocument;

    @Name("Add Doucment PopupWindow")
    @FindBy(id = "exampleModalLabel")
    public static WebElement addDoucmnetPopup;

    @Name("Document Type")
    @FindBy(id = "documentType")
    public static Select documentType;

    @Name("Document Title")
    @FindBy(id = "documentTitle")
    public static TextInput doucmentTilteText;

    @Name("Drag & Drip Button")
    @FindBy(xpath = "//img[@class='logo-width']")
    public static WebElement dragDropImageButton;

    @Name("Save Button")
    @FindBy(xpath = "(//button[contains(text(),'Save')])[2]")
    public static Button saveBtn;

    @Name("Attached Doucment Name")
    @FindBy(xpath = "(//span[contains(text(),'OsiOne_UploadDocumetns')])[1]")
    public static WebElement documentName;

    @Name("Upload Document Success Message")
    @FindBy(xpath = "//div[contains(text(),'Document saved Successfully.')]")
    public static WebElement uploadSuccessMsg;

    @Name("Deleted Document Success Message")
    @FindBy(xpath = "//div[contains(text(),'Document deleted Successfully.')]")
    public static WebElement deletedSuccessMsg;

    @Name("Delete Icon")
    @FindBy(className = "glyphicon-trash")
    public static Button deleteButton;

    @Name("Confirmation Delete Poup")
    @FindBy(xpath = "(//button[contains(text(), 'Yes')])[1]")
    public static Button confirmYesPop;

    @Name("No Attachments Message")
    @FindBy(xpath = "//*[contains(text(),'No Documents Found')]")
    public static WebElement noDoucmentsFoundTextMsg;

    @Name("File Not Found Message")
    @FindBy(xpath = "//div[contains(text(),'Please select a file to upload')]")
    public static WebElement fileNotFoundMessage;

    @Name("Select document type message")
    @FindBy(xpath = "//div[contains(text(),'Select document type')]")
    public static WebElement selectDocumentTypeMessage;

    @Name("Invoice Address")
    @FindBy(xpath = "(//td[@class='ng-binding'])[1]")
    public static TextBlock invoiceAddress;

    @Name("Communication Address")
    @FindBy(xpath = "(//td[@class='ng-binding'])[2]")
    public static TextBlock communicationAddress;

    @Name("Contact Details")
    @FindBy(xpath = "//tr[@ng-repeat='contact in vm.customerInfo.osiCustomerContacts track by $index']")
    public static TextBlock contactDetails;

    @Name("Customer Saved Message")
    @FindBy(xpath = "//div[contains(text(),'Customer saved successfully')]")
    public static WebElement customerSuccessMessage;

    public static void btnClick() {
        Actions.waitUntil(() -> documentsTab.isDisplayed(), 2000);
//        Actions.execJavascript("arguments[0].click();", documentsTab);
        documentsTab.click();
        //documents.click();
        Actions.waitUntil(() -> uploadDocument.isDisplayed(), 2000);
        uploadDocument.click();
        Actions.waitUntil(() -> addDoucmnetPopup.isDisplayed(), 2000);
    }

    public static void UploadDocuments(String fileName) throws InterruptedException, AWTException {
        new ProjectsPage().dropDownSelection("documentType", documentType);
        Actions.waitUntil(() -> doucmentTilteText.isDisplayed(), 2000);
        Actions.waitUntil(() -> dragDropImageButton.isDisplayed(), 2000);
        Actions.uploadFile(dragDropImageButton, fileName);
        saveBtn.click();
        Actions.waitUntil(() -> documentName.isDisplayed(), 2000);
        Assert.assertTrue("Doucments are not sucessfully attached", uploadSuccessMsg.isDisplayed());
        Assert.assertTrue("Documents are not upload properly", documentName.isDisplayed());
        Actions.waitUntil(() -> deleteButton.isEnabled(), 2000);
        deleteButton.click();
        Actions.waitUntil(() -> confirmYesPop.isEnabled(), 2000);
        confirmYesPop.click();
        Actions.waitUntil(() -> noDoucmentsFoundTextMsg.isDisplayed(), 2000);
        Assert.assertTrue("Attached document are not deleted properly", deletedSuccessMsg.isDisplayed());
        Assert.assertTrue("Documents are not upload properly", (!documentName.isDisplayed()));
    }

    public void verifyCustomerDetails(Customers customer, String type) {
        Assert.assertEquals(customerName.getText(), custName);
        if (type.equals("entered")) {
            Assert.assertEquals(customerLongName.getText(), custName.replace("_", ""));
        } else {
            Assert.assertEquals(customerLongName.getText(), custEditedName.replace("_", ""));
        }
        Assert.assertEquals(website.getText(), websiteName);
        Assert.assertEquals(region.getFirstSelectedOption().getText(), regionName);
        Assert.assertEquals(timezone.getFirstSelectedOption().getText(), timeZoneName);
        Assert.assertEquals(accountManager.getText().trim(), fullName);
        Assert.assertEquals(salesPersonName.getText().trim(), salesFullName);
        Assert.assertEquals(customerSourcedFrom.getFirstSelectedOption().getText(), getSourcedFrom);
        Assert.assertEquals(paymentTerms.getFirstSelectedOption().getText(), paymentTermsValue);
        Assert.assertEquals(invoiceNotes.getAttribute("value").trim(), invoiceNotesValue);
        Assert.assertEquals(taxRate.getFirstSelectedOption().getText(), taxRateValue);
        Assert.assertEquals(lateFeeTerms.getFirstSelectedOption().getText(), lateFeeTermsValue);
        Assert.assertEquals(currency.getFirstSelectedOption().getText(), currencyValue);
        Assert.assertEquals(businessDomain.getFirstSelectedOption().getText(), businessDomainValue);
    }

    public void verifyAddressDetails(Customers customer) {
        Assert.assertTrue("ERROR: Invoice address line1 is showing wrong: ", invoiceAddress.getText().contains(customer.getAddressLine1()));
        Assert.assertTrue("ERROR: Invoice address line2 is showing wrong: ", invoiceAddress.getText().contains(customer.getAddressLine2()));
        Assert.assertTrue("ERROR: Invoice address city is showing wrong:", invoiceAddress.getText().contains(customer.getCity()));
        Assert.assertTrue("ERROR: Invoice address state is showing wrong:", invoiceAddress.getText().contains(customer.getState()));
        Assert.assertTrue("ERROR: Invoie address country is showing wrong:", invoiceAddress.getText().contains(customer.getCountry()));
        Assert.assertTrue("ERROR: Invoice address zipcode is showing wrong:", invoiceAddress.getText().contains(customer.getZipcode()));
    }

    public void verifyCommunicationDetails(Customers customer) {
        Assert.assertTrue("ERROR: Communication address line1 is showing wrong: ", communicationAddress.getText().contains(customer.getAddressLine1()));
        Assert.assertTrue("ERROR: Communication address line2 is showing wrong: ", communicationAddress.getText().contains(customer.getAddressLine2()));
        Assert.assertTrue("ERROR: Communication address city is showing wrong:", communicationAddress.getText().contains(customer.getCity()));
        Assert.assertTrue("ERROR: Communication address state is showing wrong:", communicationAddress.getText().contains(customer.getState()));
        Assert.assertTrue("ERROR: Communication address country is showing wrong:", communicationAddress.getText().contains(customer.getCountry()));
        Assert.assertTrue("ERROR: Communication address zipcode is showing wrong:", communicationAddress.getText().contains(customer.getZipcode()));
    }

    public void verifyContactDetails(Customers customer) {
        contacts.click();
        Actions.waitUntil(() -> contactDetails.isDisplayed());
        Assert.assertTrue("ERROR: Contact name value is showing wrong:", contactDetails.getText().contains(addContactNameValue.replace("_", "")));
        Assert.assertTrue("ERROR: Contact details mobile number is showing wrong: ", contactDetails.getText().contains(mobileNumberValue));
        Assert.assertTrue("ERROR: Contact details email address is showing wrong: ", contactDetails.getText().contains(emailAddressValue));
    }


    public void editCustomerDetails(Customers customers) throws InterruptedException {
        custEditedName = Util.getCustomerName(5);
        customerLongName.clear();
        customerLongName.sendKeys(custEditedName);
        websiteName = Util.getRandomWebsite(custEditedName);
        website.clear();
        website.sendKeys(websiteName);
//        accountManager.clear();
//        Thread.sleep(1000);
//        accountManager.sendKeys(acctManager);
//        accountManager.sendKeys(Keys.TAB);
//        Thread.sleep(1000);
////        Actions.waitUntil(() -> empListLabel.isDisplayed(), 2000);
//        fullName = getAccuontManagerDetailsNames(acctManager);
//        empNames = empList.stream().filter(a -> a.getText().equals(fullName)).collect(Collectors.toList()).get(0);
//        Actions.execJavascript("arguments[0].scrollIntoView();", empNames);
////        org.openqa.selenium.interactions.Actions actions = new org.openqa.selenium.interactions.Actions(Browser.getDriver());
//        Actions.doubleClick(empNames);
//        Thread.sleep(1000);
////        Actions.waitUntil(() -> !empListLabel.isDisplayed(), 1000);
//        salesPersonName.clear();
//        Thread.sleep(1000);
//        salesPersonData = Util.getRandomManagerFirstName();
//        salesPersonName.sendKeys(salesPersonData);
//        salesPersonName.sendKeys(Keys.TAB);
////        Actions.waitUntil(() -> empListLabel.isDisplayed(), 2000);
//        Thread.sleep(1000);
//        salesFullName = getAccuontManagerDetailsNames(salesPersonData);
//        empNames1 = empList.stream().filter(a -> a.getText().equals(salesFullName)).collect(Collectors.toList()).get(0);
////        org.openqa.selenium.interactions.Actions a = new org.openqa.selenium.interactions.Actions(Browser.getDriver());
//        Actions.doubleClick(empNames1);
//        Thread.sleep(1000);
//        Actions.waitUntil(() -> !empListLabel.isDisplayed(), 1000);
    }

    public void editInvoiceAdressDetails(Customers customers) throws InterruptedException {
        Actions.execJavascript("arguments[0].click()", address);
        Actions.execJavascript("arguments[0].click()", editInvoiceAddress);
        Actions.waitUntil(() -> addressline1.isDisplayed(), 2000);
        addressline1Value = customers.getAddressLine1();
        addressline2Value = customers.getAddressLine2();
        countryValue = customers.getCountry();
        stateValue = customers.getState();
        cityValue = customers.getCity();
        zipcodeValue = customers.getZipcode();
        addressline1.clear();
        addressline1.sendKeys(addressline1Value);
        addressLine2.clear();
        addressLine2.sendKeys(addressline2Value);
        country.selectByVisibleText(countryValue);
        state.selectByVisibleText(stateValue);
        city.clear();
        city.sendKeys(cityValue);
        zipcode.clear();
        zipcode.sendKeys(zipcodeValue);
        Actions.execJavascript("arguments[0].click()", addButton);
        Actions.waitUntil(() -> !addButton.isDisplayed(), 2000);
    }

    public void editCommunicationAdressDetails(Customers customers) throws InterruptedException {
        Actions.execJavascript("arguments[0].click()", editCommunicationAddress);
        Actions.waitUntil(() -> addressline1.isDisplayed(), 2000);
        addressline1Value = customers.getAddressLine1();
        addressline2Value = customers.getAddressLine2();
        countryValue = customers.getCountry();
        stateValue = customers.getState();
        cityValue = customers.getCity();
        zipcodeValue = customers.getZipcode();
        addressline1.clear();
        addressline1.sendKeys(addressline1Value);
        addressLine2.clear();
        addressLine2.sendKeys(addressline2Value);
        Actions.execJavascript("arguments[0].scrollIntoView()", country);
        country.selectByVisibleText(countryValue);
        Actions.execJavascript("arguments[0].scrollIntoView()", state);
        state.selectByVisibleText(stateValue);
        city.clear();
        city.sendKeys(cityValue);
        zipcode.clear();
        zipcode.sendKeys(zipcodeValue);
        Actions.execJavascript("arguments[0].click()", addButton);
        Actions.waitUntil(() -> !addButton.isDisplayed(), 2000);
    }

    public void editContactsDetails(Customers customers) throws InterruptedException {
        Actions.execJavascript("arguments[0].scrollIntoView()", contacts);
        Actions.execJavascript("arguments[0].click()", contacts);
        Actions.execJavascript("arguments[0].scrollIntoView()", editContactDetails);
        Actions.execJavascript("arguments[0].click()", editContactDetails);
        addContactNameValue = Util.getCustomerName(5);
        Actions.waitUntil(() -> addContactName.isDisplayed());
        Actions.execJavascript("arguments[0].scrollIntoView()", addContactName);
        Actions.execJavascript("arguments[0].click()", addContactName);
        addContactName.clear();
        addContactName.sendKeys((addContactNameValue));
        mobileNumberValue = Util.getRandomMobleNumber();
        Actions.execJavascript("arguments[0].scrollIntoView()", contactNumber);
        Actions.execJavascript("arguments[0].click()", contactNumber);
        contactNumber.clear();
        contactNumber.sendKeys(mobileNumberValue);
        emailAddressValue = Util.generateRandomEmail(8);
        Actions.execJavascript("arguments[0].scrollIntoView()", emailAddress);
        Actions.execJavascript("arguments[0].click()", emailAddress);
        emailAddress.clear();
        emailAddress.sendKeys(emailAddressValue);
        alternateMobileNumberValue = Util.getRandomMobleNumber();
        Actions.execJavascript("arguments[0].scrollIntoView()", alternateContactNumber);
        Actions.execJavascript("arguments[0].click()", alternateContactNumber);
        alternateContactNumber.clear();
        alternateContactNumber.sendKeys(alternateMobileNumberValue);
        Actions.execJavascript("arguments[0].scrollIntoView()", addContactsButton);
        Actions.execJavascript("arguments[0].click();", addContactsButton);
        Actions.waitUntil(() -> !addContactsButton.isDisplayed(), 1000);
    }
}
