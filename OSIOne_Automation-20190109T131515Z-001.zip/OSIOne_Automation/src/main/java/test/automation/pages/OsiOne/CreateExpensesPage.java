package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.*;
import test.automation.framework.Actions;
import test.automation.framework.Browser;
import test.automation.framework.Config;
import test.automation.framework.Page;
import test.automation.utils.OsiOneData;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * Created by amolleti on 9/25/2018.
 */
public class CreateExpensesPage extends Page {
    public static final String URL = Config.getUrl() + "/a5/#/expenses/create-expense";
    public static final By VERIFY_BY = By.xpath("//b[contains(text(),\"Expense Start Date\")]");
    private ExpensesPage expensesPage = new ExpensesPage();
    public static List<HashMap<String, WebElement>> userTable = new ArrayList<HashMap<String, WebElement>>();
    public static String AddExpenseDate;
    public static String ExpenseStartDate;

    @Name("plus enabled")
    @FindBy(xpath = "(//*[@data-toggle=\"modal\"])[1]")
    public static TextBlock enablebutton;

    @Name("create expenses")
    @FindBy(xpath = "//*[@class=\"glyphicon glyphicon-plus\"]")
    public static Link createExpenses;

    @Name("Date picker")
    @FindBy(xpath = "(//*[@class='fa fa-lg fa-calendar date-pick'])[1]")
    public static TextBlock datepicker;

    @Name("Date picker")
    @FindBy(xpath = "(//*[@class='fa fa-lg fa-calendar date-pick'])[2]")
    public static TextBlock datepicker1;

    @Name("ADD Expenses Date")
    @FindBy(xpath = "//*[@id=\"add_expense\"]//*[@class=\"input-group\"]/input")
    public static TextInput addExpenseDate;

    @Name("Expense Date")
    @FindBy(xpath = "(//*[@class='fa fa-lg fa-calendar date-pick'])[2]")
    public static TextBlock expenseDate;

    @Name("Project")
    @FindBy(xpath = "(//*[@id=\"addProjectId\"])[1]")
    public static Select project;

    @Name("Task")
    @FindBy(xpath = "(//*[@id=\"addProjectTask\"])[1]")
    public static Select task;

    @Name("Expenses")
    @FindBy(xpath = "(//*[@id=\"addExpenseTypeId\"])[1]")
    public static Select expenses;

    @Name("Recipet Currency")
    @FindBy(xpath = "(//*[@id=\"addCurrencyCode\"])[1]")
    public static Select recipetCurrency;

    @Name("Quantity")
    @FindBy(xpath = "(//*[@id=\"addQuantity\"])[1]")
    public static TextInput quantity;

    @Name("Quantity")
    @FindBy(xpath = "(//*[@id=\"addReceiptPrice\"])[1]")
    public static TextInput recepitPrice;

    @Name("ADD Button")
    @FindBy(xpath = "(//*[contains(text(),\"Add\")])[2]")
    public static Link addButton;

    @Name("Create Expenses Table")
    @FindBy(xpath = "//*[@class=\"table table-bordered create-expensive\"]")
    public static Table createExpensesReport;

    @Name("Report checkbox click")
    @FindBy(xpath = "(//*[@class='table table-bordered create-expensive']//td)[16]/input")
    public static CheckBox saveExpenses;

    @Name("Save Button")
    @FindBy(xpath = "//button[contains(text(),'Save')]")
    public static Button saveButtonExpenses;

    @Name("Save Button")
    @FindBy(xpath = "//button[contains(text(),'Submit')]")
    public static Button submitButtonExpenses;

    @Name("submit popup confirmation")
    @FindBy(xpath = "(//*[contains(text(),'Yes')])[3]")
    public static Button expensesSubmitConfirmation;

    @Name("Month Navigation")
    @FindBy(xpath = "(//*[@class=\"ngb-dp-navigation-chevron\"])[1]")
    public static WebElement navigationlink;

    @Name("Expense Start Date")
    @FindBy(xpath = "//*[@id=\"exstartdate\"]")
    public static TextInput expenseStartDate;

    @Name("submit popup")
    @FindBy(xpath = "//*[@id=\"submit_expense\"]//h5")
    public static TextBlock confirmatonMessage;

    @Name("enable date in expense")
    @FindBy(xpath = "//*[@class='ngb-dp-day']//*[@class='btn-light']")
    public static Link date;

    public void randomDate(WebElement element) throws InterruptedException {
//        Actions.execJavascript("arguments[0].click();", element);
        element.click();
        List<WebElement> dates = Browser.getDriver().findElements(By.xpath("//*[@class=\"btn-light\"]"));
        WebElement randomselect = dates.get(new Random().nextInt(dates.size()));
//        Actions.execJavascript("arguments[0].click();", randomselect);
        randomselect.click();
    }

    public void expenseDate(WebElement element) throws InterruptedException {
        Actions.execJavascript("arguments[0].click();", element);
        Actions.waitUntil(() -> date.isDisplayed(), 10);
        List<WebElement> l = Browser.getDriver().findElements(By.xpath("//*[@class='ngb-dp-day']"));
        WebElement e = l.get(l.size() - 1);
        e.click();
        AddExpenseDate = addExpenseDate.getAttribute("value");
    }

    public void addExpensesDetails() throws InterruptedException, SQLException {
        expensesPage.createExpensesButton.click();
        ExpenseStartDate = expenseStartDate.getAttribute("value");
        if (enablebutton.getAttribute("class").equals("disabled")) {
            Browser.getDriver().navigate().back();
            new OsiOneData().deleteExpenses(ExpenseStartDate);
            Actions.execJavascript("arguments[0].click();", ViewExpenses.submitted);
            expensesPage.createExpensesButton.click();
        }
        Actions.waitUntilElementNotPresent(expensesPage.createExpensesButton);
        new OsiOneData().deleteExpenses(ExpenseStartDate);
        createExpenses.click();
        Actions.waitUntilElementPresent(project);
        project.selectByVisibleText("Nuemera_PCBS System");
        task.selectByVisibleText("Developer");
        expenseDate(datepicker1);
        expenses.selectByVisibleText("Computer Spares");
        quantity.sendKeys("5");
        recipetCurrency.selectByVisibleText("INR");
        recepitPrice.sendKeys("30");
        Actions.execJavascript("arguments[0].scrollIntoView();", addButton);
        addButton.click();
    }

    public List<HashMap<String, WebElement>> TableData(Table element) throws InterruptedException {
        List<WebElement> rowElements = element.findElements(By.xpath(".//tr"));
        ArrayList<String> columnNames = new ArrayList<String>();
        List<WebElement> headerElements = rowElements.get(0).findElements(By.xpath(".//td"));
        for (WebElement headerElement : headerElements) {
            columnNames.add(headerElement.getText());
        }
        rowElements.remove(0);
        for (WebElement rowElement : rowElements) {
            HashMap<String, WebElement> row = new HashMap<String, WebElement>();
            int columnIndex = 0;
            List<WebElement> cellElements = rowElement.findElements(By.xpath(".//td"));
            for (WebElement cellElement : cellElements) {
                row.put(columnNames.get(columnIndex), cellElement);
                columnIndex++;
            }
            userTable.add(row);
        }
        return userTable;
    }

}
