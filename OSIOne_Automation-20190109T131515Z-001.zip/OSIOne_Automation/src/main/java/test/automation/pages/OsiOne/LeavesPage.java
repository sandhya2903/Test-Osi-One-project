package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import test.automation.framework.Actions;
import test.automation.framework.Config;
import test.automation.framework.Page;

/**
 * Created by vemanepalli on 20-Sep-18.
 */
public class LeavesPage extends Page {

    public static final String URL = Config.getUrl() + "/a5/#/leaves/viewleaves";
    public static final By VERIFY_BY = By.xpath("//h1[contains(text(),'My Leaves')]");

    @Name("Add Leaves Button")
    @FindBy(xpath = "//*[@class='glyphicon glyphicon-plus']")
    public static WebElement addButton;

    public static void performLeaveOperations() throws InterruptedException {
       //Actions.execJavascript("arguments[0].click()", addButton);
        addButton.click();
    }

}
