package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import test.automation.framework.Config;
import test.automation.framework.Page;

/**
 * Created by vemanepalli on 18-Sep-18.
 */
public class ViewCustomerPage extends Page {

    public static final String URL = Config.getUrl() + "/a1/#/editCustomer";
    //public static final By VERIFY_BY = By.xpath("//a[contains(text(),'View Customer')]");
    public static final By VERIFY_BY = By.xpath("//*[@class='breadcrumb-item active ng-binding']");

}
