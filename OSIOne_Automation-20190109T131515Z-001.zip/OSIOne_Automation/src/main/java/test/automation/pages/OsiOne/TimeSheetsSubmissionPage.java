package test.automation.pages.OsiOne;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.*;
import test.automation.framework.*;
//import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.apache.commons.collections.ListUtils.subtract;

public class TimeSheetsSubmissionPage extends Page {

    private static HomePage homePage = new HomePage();
    private static List<Integer> finalList;
    private static List<Integer> total;
    private static List<List<Integer>> listArrays = new ArrayList<List<Integer>>();
    private static List<Integer> fList = new ArrayList<Integer>();

    public static final String URL = Config.getUrl() + "/a1/#/weeklyTimeSheet";
    public static final By VERIFY_BY = By.id("activeBread");

    @Name("Add TimeSheet")
    @FindBy(id = "addWeeklyEntryBtn")
    public static Button addTimeSheetsButton;

    @Name("Weekly Tag")
    @FindBy(id = "weeklyTag")
    public static TextBlock weeklyTag;

    @Name("Confirmation Modal")
    @FindBy(id = "confirmationModal")
    public static Link confirmationModal;

    @Name("Hours Header")
    @FindBy(xpath = "//thead[@class='thead_bg text-center']")
    public static TextBlock hoursHeader;

    @Name("Project Id")
    @FindBy(id = "projectId")
    public static Select projectId;

    @Name("Task Id")
    @FindBy(id = "taskId")
    public static Select taskId;

    @Name("Shift Id")
    @FindBy(id = "shiftId")
    public static Select shiftId;

    @Name("Bill Type Id")
    @FindBy(id = "billTypeId")
    public static Select billTypeId;

    @Name("Monday Hours Entry")
    @FindBy(id = "day1Note_0")
    public static TextInput mondayHoursInput;

    @Name("Monday Notes Entry")
    @FindBy(xpath = "//span[@id='day1Note_0']")
    public static TextInput mondayNotesInput;

    @Name("Tuesday Hours Entry")
    @FindBy(id = "day2Note_0")
    public static TextInput tuesdayHoursInput;

    @Name("Tuesday Notes Entry")
    @FindBy(xpath = "//span[@id='day2Note_0']")
    public static TextInput tuesdayNotesInput;

    @Name("Wednesday Hours Entry")
    @FindBy(id = "day3Note_0")
    public static TextInput wednesdayHoursInput;

    @Name("Wednesday Notes Entry")
    @FindBy(xpath = "//span[@id='day3Note_0']")
    public static TextInput wednesdayNotesInput;

    @Name("Thursday Hours Entry")
    @FindBy(id = "day4Note_0")
    public static TextInput thursdayHoursInput;

    @Name("Thursday Notes Entry")
    @FindBy(xpath = "//span[@id='day4Note_0']")
    public static TextInput thursdayNotesInput;

    @Name("Friday Hours Entry")
    @FindBy(id = "day5Note_0")
    public static TextInput fridayHoursInput;

    @Name("Friday Notes Entry")
    @FindBy(xpath = "//span[@id='day5Note_0']")
    public static TextInput fridayNotesInput;

    @Name("Saturday Hours Entry")
    @FindBy(id = "day6Note_0")
    public static TextInput saturdayHoursInput;

    @Name("Sadurday Notes Entry")
    @FindBy(xpath = "//span[@id='day6Note_0']")
    public static TextInput saturdayNotesInput;

    @Name("Sunday Hours Entry")
    @FindBy(id = "day7Note_0")
    public static TextInput sundayHoursInput;

    @Name("Sunday Notes Entry")
    @FindBy(xpath = "//span[@id='day7Note_0']")
    public static TextInput sundayNotesInput;

    @Name("Task Rows")
    @FindBy(xpath = "//tr[@ng-repeat='timeSheetEntry in vm.tsRows track by $index']")
    public static List<WebElement> taskRows;

    @Name("Delete Entries")
    @FindBy(xpath = "//button[@ng-disabled='timeSheetEntry.isLeaveEntry']")
    public static Button deleteRowsButton;

    @Name("Save Timesheets")
    @FindBy(xpath = "//*[contains(text(),'Save')]")
    public static Button saveTimesheets;

    @Name("Submit Timesheets")
    @FindBy(xpath = "(//*[contains(text(),'Submit')])[2]")
    public static Button submitTimesheets;

    @Name("Comments")
    @FindBy(id = "comment")
    public static TextInput commentInput;

    @Name("Comments Ok Button")
    @FindBy(xpath = "//button[contains(text(),'Ok')]")
    public static Button okButton;

    @Name("Project Id List")
    @FindBy(xpath = "//tr[@ng-repeat='timeSheetEntry in vm.tsRows track by $index']//td[1]//select")
    public static List<Select> projectIdsList;

    @Name("Logout Link Button")
    @FindBy(xpath = "//a[contains(text(),'Logout')]")
    public static Link logoutLinkButton;

    @Name("Timesheets Submitted Success Message")
    @FindBy(xpath = "//*[contains(text(),'Timesheet Submitted Successfully')]")
    public static TextBlock timesheetsSubmitSuccessMessage;

    @Name("Timesheets Saved Success Message")
    @FindBy(xpath = "//*[contains(text(),'Timesheet Saved Successfully')]")
    public static TextBlock timesheetsSavedSuccessMessage;

    @Name("Week Start Date")
    @FindBy(xpath = "//*[@class='nav-link active']")
    public static Link weekStartDate;

    @Name("Back Button")
    @FindBy(xpath = "//button[contains(text(),'Back')]")
    public static Button backButton;

    @Name("Dashboard")
    @FindBy(css = "#dashboard > a")
    public static Link dashboard;

    @Name("My Profile")
    @FindBy(css = "#profile > a")
    public static Link myProfile;

    public static String weekStartDateText;
    public static String[] Timesheetdate;
    public static String[] Monthwithdate;
    public static String Datevalue;

    public void saveTimesheets() throws InterruptedException {
        Thread.sleep(500);
        saveTimesheets.click();
        Thread.sleep(500);
        homePage.dashboard.click();
    }

    public void submitTimesheets() throws InterruptedException {
        onPage(TimeSheetsSubmissionPage.class);
        weekStartDateText = weekStartDate.getText();
        Actions.execJavascript("arguments[0].click();", submitTimesheets);
        Assert.assertTrue("Timesheet not Submitted Successfully", timesheetsSubmitSuccessMessage.isDisplayed());
        onPage(TimeSheetsSubmissionPage.class);
        Actions.waitUntil(() -> addTimeSheetsButton.isDisplayed());
    }

    public void logoutPage() throws InterruptedException {
        Actions.waitUntil(() -> logoutLinkButton.isDisplayed(), 2000);
        Actions.execJavascript("arguments[0].click();", logoutLinkButton);
        Thread.sleep(1000);

    }

    public void navigateToWeeklyTimeSheetsPage() throws InterruptedException {
        onPage(HomePage.class);
        Actions.execJavascript("arguments[0].click()", homePage.newTimeSheets);
        Thread.sleep(2000);
        homePage.addTimesheet.click();

    }
    public String date(){
        Timesheetdate = weekStartDate.getText().split("\n");
        Monthwithdate = Timesheetdate[1].split("-");
        Datevalue = Monthwithdate[0] + "-" + Timesheetdate[0] + "-19";
        return Datevalue;
    }

    public List<Integer> leavesAndHolidays(Integer rowNumber) {
        List<Integer> results = new ArrayList<>();
        for (int i = 1; i < 7; i++) {
            String notesPath = "//span[@id='day" + i + "Note_" + rowNumber + "']";
            String hoursPath = "//input[@id='day" + i + "Note_" + rowNumber + "']";
            TextInput hoursEntry = new TextInput(Browser.getDriver().findElement(By.xpath(hoursPath)));
            TextInput notesEntry = new TextInput(Browser.getDriver().findElement(By.xpath(notesPath)));
            if (notesEntry.getAttribute("class").contains("changeColor")) {
                results.add(i);
            }
        }
        return results;
    }

    public void addHours() throws InterruptedException {
        if (projectIdsList.size() == 0) {
//            Actions.execJavascript("arguments[0].click()", addTimeSheetsButton);
            addTimeSheetsButton.click();
        }

        Thread.sleep(500);
        Integer numOfRows = projectIdsList.size();
        total = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        for (int i = 0; i < numOfRows; i++) {
            Thread.sleep(500);
            List<Integer> lAndH = leavesAndHolidays(i);
            listArrays.add(lAndH);
            if (projectIdsList.get(i).getFirstSelectedOption().getText().equals("Select")) {
                int k = i + 1;
                String projectSelectOption = "//tr[@ng-repeat='timeSheetEntry in vm.tsRows track by $index']" + "[" + k + "]" + "//td[1]//select";
                String taskOption = "//tr[@ng-repeat='timeSheetEntry in vm.tsRows track by $index']" + "[" + k + "]" + "//td[2]//select";
                String shiftOption = "//tr[@ng-repeat='timeSheetEntry in vm.tsRows track by $index']" + "[" + k + "]" + "//td[3]//select";
                String billTypeOption = "//tr[@ng-repeat='timeSheetEntry in vm.tsRows track by $index']" + "[" + k + "]" + "//td[4]//select";

                Select projectEntry = new Select(Browser.getDriver().findElement(By.xpath(projectSelectOption)));
                Select taskEntry = new Select(Browser.getDriver().findElement(By.xpath(taskOption)));
                Select shiftEntry = new Select(Browser.getDriver().findElement(By.xpath(shiftOption)));
                Select billTypeEntry = new Select(Browser.getDriver().findElement(By.xpath(billTypeOption)));

                projectEntry.selectByVisibleText("Practice_ET (IN)");
                taskEntry.selectByVisibleText("Practice");
                shiftEntry.selectByVisibleText("General Shift (9am to 6pm)");
                billTypeEntry.selectByVisibleText("INTERNAL");

                for (int j = 1; j <= listArrays.size(); j++) {
                    fList.addAll(listArrays.get(j - 1));
                }

                finalList = fList.equals(null) ? total : subtract(total, fList);
                Integer finalListSize = fList.equals(null) ? total.size() : subtract(total, fList).size();

                for (int j = 1; j <= finalListSize; j++) {
                    String notesPath = "//span[@id='day" + finalList.get(j - 1) + "Note_" + i + "']";
                    String hoursPath = "//input[@id='day" + finalList.get(j - 1) + "Note_" + i + "']";
                    TextInput hoursEntry = new TextInput(Browser.getDriver().findElement(By.xpath(hoursPath)));
                    TextInput notesEntry = new TextInput(Browser.getDriver().findElement(By.xpath(notesPath)));
                    if (!notesEntry.getAttribute("class").contains("changeColor")) {
                        hoursEntry.sendKeys("8");
                        Thread.sleep(1000);
                        notesEntry.click();
                        Wait.secondsUntilElementPresent(commentInput, 5);
                        commentInput.sendKeys("practice");
                        okButton.click();
                    }
                }
            }
        }
    }

    public void addNewHoursEntry() throws InterruptedException {
        projectId.selectByVisibleText("Practice_ET (IN)");
        taskId.selectByVisibleText("Practice");
        shiftId.selectByVisibleText("General Shift (9am to 6pm)");
        billTypeId.selectByVisibleText("INTERNAL");
//        mondayHoursInput.sendKeys("8");
//        mondayNotesInput.click();
//        Actions.waitUntil(() -> commentInput.isDisplayed());
//        commentInput.sendKeys("Practice");
//        okButton.click();
//        Actions.waitUntil(() -> !commentInput.isDisplayed());
//        tuesdayHoursInput.sendKeys("8");
//        tuesdayNotesInput.click();
//        Actions.waitUntil(() -> commentInput.isDisplayed());
//        commentInput.sendKeys("Practice");
//        okButton.click();
//        Actions.waitUntil(() -> !commentInput.isDisplayed());
//        wednesdayHoursInput.sendKeys("8");
//        wednesdayNotesInput.click();
//        Actions.waitUntil(() -> commentInput.isDisplayed());
//        commentInput.sendKeys("Practice");
//        okButton.click();
//        Actions.waitUntil(() -> !commentInput.isDisplayed());
//        thursdayHoursInput.sendKeys("8");
//        thursdayNotesInput.click();
//        Actions.waitUntil(() -> commentInput.isDisplayed());
//        commentInput.sendKeys("Practice");
//        okButton.click();
//        Actions.waitUntil(() -> !commentInput.isDisplayed());
//        fridayHoursInput.sendKeys("8");
//        fridayNotesInput.click();
//        Actions.waitUntil(() -> commentInput.isDisplayed());
//        commentInput.sendKeys("Practice");
//        okButton.click();
//        Actions.waitUntil(() -> !commentInput.isDisplayed());
    }
}
