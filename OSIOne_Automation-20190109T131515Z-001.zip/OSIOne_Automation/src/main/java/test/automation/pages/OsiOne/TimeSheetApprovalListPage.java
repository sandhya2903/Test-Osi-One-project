package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.TextBlock;
import test.automation.framework.Actions;
import test.automation.framework.Config;
import test.automation.framework.Page;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by vemanepalli on 08-Oct-18.
 */
public class TimeSheetApprovalListPage extends Page {
    public static final String URL = Config.getUrl() + "/a1/#/timeSheetApprovalList";
    public static final By VERIFY_BY = By.xpath("//*[contains(text(),'Timesheets for approval')]");

    @Name("Timesheets Approval table data")
    @FindBy(xpath = "//*[@class='table-responsive']//tbody/tr//input")
    public static List<WebElement> timesheetsApprovalTableList;

    @Name("TimeSheets Resources View table data")
    @FindBy(xpath = "//*[@id='tsApprTds']/tr/td[2]")
    public static List<WebElement> timeSheetsResourcesView;

    @Name("TimeSheet Resource View Text")
    @FindBy(xpath = "//*[contains(text(),'Timesheets Resource View')]")
    public static TextBlock timeSheetResourceViewText;

    @Name("Approve Button")
    @FindBy(xpath = "//button[@ng-click='vm.approveTimesheets(vm.empApprovalDTO)']")
    public static Button approveButton;

    @Name("Timesheet Approved Success Message")
    @FindBy(xpath = "//*[contains(text(),'Timesheet has been approved successfully.')]")
    public static TextBlock timesheetApprovedSuccessMessage;

    @Name("Reject Button")
    @FindBy(xpath = "//button[contains(text(),'Reject')]")
    public static Button rejectTimeSheetButton;

    @Name("Reason Text")
    @FindBy(xpath = "//*[contains(text(),'Reason')]")
    public static TextBlock reasonLabelText;

    @Name("Reason popup comment textbox")
    @FindBy(id = "comment")
    public static TextBlock commentSection;

    @Name("OK button on Rejected popup window")
    @FindBy(xpath = "//button[@ng-click='vm.rejectAllTimesheets(vm.empApprovalDTO)']")
    public static Button okButton;

    @Name("Timesheet Rejection Success Message")
    @FindBy(xpath = "//*[contains(text(),'Timesheet has been rejected successfully')]")
    public static TextBlock timeSheetRejectionMessage;

    public static WebElement selectRecord;

    public static List<WebElement> employeeNameLists = new ArrayList<>();

    public static String rejectionReason;


    public void timeSheetEmployeeData() throws InterruptedException {

        selectRecord = timesheetsApprovalTableList.get(timesheetsApprovalTableList.size() - 1);
        Thread.sleep(1000);
        selectRecord.click();
        Thread.sleep(2000);
        Actions.waitUntil(() -> timeSheetResourceViewText.isDisplayed(), 2000);
        employeeNameLists = timeSheetsResourcesView.stream().filter(a -> a.getText().contains("Raju Donepudi")).collect(Collectors.toList());
        employeeNameLists.get(0).click();
        Thread.sleep(1000);

    }

    public void timesheetApprovedByRM() throws InterruptedException {
        approveButton.click();
        Thread.sleep(1000);
//        Actions.waitUntilElementPresent(timesheetApprovedSuccessMessage);
//        Assert.assertTrue("Timesheet not approved successfully.", timesheetApprovedSuccessMessage.isDisplayed());
        //Actions.waitUntil(() -> timeSheetResourceViewText.isDisplayed(), 2000);
    }


    public void timeSheetRejectedByRM() throws InterruptedException {
        Thread.sleep(1000);
        rejectTimeSheetButton.click();
        Actions.waitUntilElementPresent(reasonLabelText);
        rejectionReason = "please make comments full descripton";
        commentSection.sendKeys(rejectionReason);
        okButton.click();
        Thread.sleep(2000);
    }

}
