package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Link;
import test.automation.framework.Config;
import test.automation.framework.Page;

/**
 * Created by amolleti on 10/10/2018.
 */
public class EmpProfilePage extends Page {
    public static final String URL = Config.getUrl() + "/a1/#/profile";
    public static final By VERIFY_BY = By.xpath("(//*[contains(text(),' Organization')])[1]");

    @Name("Dashboard")
    @FindBy(css = "#dashboard > a")
    public static Link dashboard;
}
