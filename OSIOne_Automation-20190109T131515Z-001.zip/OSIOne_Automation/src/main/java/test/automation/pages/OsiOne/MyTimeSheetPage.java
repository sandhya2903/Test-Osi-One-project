package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Link;
import ru.yandex.qatools.htmlelements.element.Select;
import ru.yandex.qatools.htmlelements.element.TextBlock;
import test.automation.framework.Browser;
import test.automation.framework.Config;
import test.automation.framework.Page;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by vemanepalli on 11-Oct-18.
 */
public class MyTimeSheetPage extends Page {

    public static final String URL = Config.getUrl() + "/a1/#/employeeTimeSheet";
    public static final By VERIFY_BY = By.xpath("//*[contains(text(),' Select Range')] ");
    public static List<WebElement> rowElements = new ArrayList<>();
    public static List<HashMap<String, WebElement>> userTable = new ArrayList<HashMap<String, WebElement>>();

    @Name("Date Range")
    @FindBy(id = "startDate")
    public static Select rangeselect;

    @Name("Click on Range")
    @FindBy(id = "startDate")
    public static Link range;

    @Name("Status")
    @FindBy(id = "status")
    public static Select statusSelect;

    @Name("submitted")
    @FindBy(className = "table table-striped table-hover table-fixed")
    public static TextBlock submitteddata;


    public List<HashMap<String, WebElement>> TableData() throws InterruptedException {
        List<WebElement> e = Browser.getDriver().findElements(By.xpath(".//tr"));
        e.remove(0);
        ArrayList<String> columnNames = new ArrayList<String>();
        List<WebElement> headerElements = e.get(0).findElements(By.xpath(".//th"));
        for (WebElement headerElement : headerElements) {
            columnNames.add(headerElement.getText());
        }
        e.remove(0);
        List<WebElement> t = e.stream().filter(a -> a.getText().contains("21 May 2018")).collect(Collectors.toList());
        for (WebElement rowElement : t) {
            HashMap<String, WebElement> row = new HashMap<String, WebElement>();
            int columnIndex = 0;
            List<WebElement> cellElements = rowElement.findElements(By.xpath(".//td"));
            for (WebElement cellElement : cellElements) {
                row.put(columnNames.get(columnIndex), cellElement);
                columnIndex++;
            }
          userTable.add(row);
        }
        return userTable;
    }

}
