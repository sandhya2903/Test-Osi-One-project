package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import test.automation.framework.Config;
import test.automation.framework.Page;

/**
 * Created by vemanepalli on 24-Sep-18.
 */
public class EditLeaveRequestPage extends Page{
    public static final String URL = Config.getUrl() + "a5/#/leaves/viewleaves/editleaverequest/48";
    public static final By VERIFY_BY = By.xpath("//h1[contains(text(),'Edit Leave Request')]");
}
