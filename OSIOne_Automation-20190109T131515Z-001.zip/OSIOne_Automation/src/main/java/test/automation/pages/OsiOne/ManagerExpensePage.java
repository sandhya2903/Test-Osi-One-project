package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Link;
import test.automation.framework.Config;
import test.automation.framework.Page;

import java.util.List;

/**
 * Created by amolleti on 10/4/2018.
 */
public class ManagerExpensePage extends Page {

    public static final String URL = Config.getUrl() + "/a5/#/expenses/manager-expense";
    public static final By VERIFY_BY = By.xpath("//*[contains(text(),\"Approve Expense Reports\")]");

    @Name("Row data")
    @FindBy(xpath = "//*[@class=\"ag-body-container\"]//*[@role=\"row\"]/div")
    public static List<WebElement> rowData;

    @Name("Logout")
    @FindBy(xpath = "//*[contains(text(),\"Logout\")]")
    public static Link logout;
}
