package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.TextBlock;
import ru.yandex.qatools.htmlelements.element.TextInput;
import test.automation.framework.Config;
import test.automation.framework.Page;

/**
 * Created by amolleti on 10/5/2018.
 */
public class ManagerApprovePage extends Page {
    public static final String URL = Config.getUrl() + "/a5/#/expenses/manager-approve";
    public static final By VERIFY_BY = By.xpath("//*[contains(text(),\"Approve Expenses\")]");

    @Name("Approve")
    @FindBy(xpath = "//*[@data-target=\"#approve_expense\"]")
    public static Button approve;

    @Name("Reject")
    @FindBy(xpath = "//*[@data-target=\"#reject_expense\"]")
    public static Button reject;

    @Name("Checkbox")
    @FindBy(xpath = "(//*[@class='table table-bordered table-responsive approve-expenses']//td)[13]/input")
    public static TextBlock checkbox;

    @Name("Confirmation popup")
    @FindBy(xpath = "//*[@id=\"approve_expense\"]//h5")
    public static TextBlock confirmationMessage;

    @Name("submit popup confirmation")
    @FindBy(xpath = "(//*[contains(text(),'Yes')])[2]")
    public static Button approveSubmitConfirmation;

    @Name("reject Reason")
    @FindBy(name = "rejectReason")
    public static TextInput rejectReason;

    @Name("Submit ")
    @FindBy(xpath = "(//*[contains(text(),\"Submit\")])[2]")
    public static Button submit;

}
