package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import test.automation.framework.Config;
import test.automation.framework.Page;

/**
 * Created by amolleti on 9/25/2018.
 */
public class ExpensesPage extends Page {

    public static final String URL = Config.getUrl() + "/a5/#/expenses/view-expenses";
    public static final By VERIFY_BY = By.xpath("//*[contains(text(),\"Create Expense\")]");

    @Name("Create Expenses Button")
    @FindBy(xpath = "//*[contains(text(),\"Create Expense\")]")
    public Button createExpensesButton;


}
