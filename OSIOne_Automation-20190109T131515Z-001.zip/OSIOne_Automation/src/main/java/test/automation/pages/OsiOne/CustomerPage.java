package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.*;
import ru.yandex.qatools.htmlelements.element.Button;
import test.automation.framework.Actions;
import test.automation.framework.Config;
import test.automation.framework.Page;

import java.util.ArrayList;
import java.util.List;

import static test.automation.framework.Runner.log;

public class CustomerPage extends Page {

    public static final String URL = Config.getUrl() + "/a1/#/customers";
    public static final By VERIFY_BY = By.id("inputsm");

    @Name("Add Customer")
    @FindBy(xpath = "//button[contains(text(), 'Add Customer')]")
    public static Button addCustomer;

    @Name("Home Page Navigation From Breadcrumb")
    @FindBy(xpath = "//a[contains(text(),'HRMS')]")
    public static Link hrms;

    @Name("Search Icon")
    @FindBy(xpath = "//span[@ng-click='vm.serachCus(customerName)']")
    public static Button searchIcon;

    @Name("Customers Search Box")
    @FindBy(id = "inputsm")
    public static TextInput customersSearch;

    @Name("Search Button")
    @FindBy(xpath = "(//button[contains(text(),'Search')])[2]")
    public static Button searchButton;

    @Name("Edit Icon")
    @FindBy(xpath = "//span[(@title='Edit')]")
    public static Button editIcon;


    @Name("Add Icon")
    @FindBy(xpath = "//span[(@title='Add')]")
    public static Button addIcon;

    @Name("View Icon")
    @FindBy(xpath = "//span[(@title='View')]")
    public static Button viewIcon;

    @Name("Please Select A Customer To View Message")
    @FindBy(xpath = "//div[contains(text(),'Please select a Customer to view')]")
    public static WebElement selectCustomerToViewMsg;

    @Name("All Customer Records")
    @FindBy(xpath = "//table[@id='tsCustomerListTbl']/tbody")
    public static List<WebElement> getAllCustomerRecords;

    @Name("Customer Record Rows")
    @FindBy(xpath = "//tr[@ng-click='vm.setCustomerRowIndex($index, customer)']")
    public static List<WebElement> getCustomerRecordRows;

    @Name("Customer Names List")
    @FindBy(xpath = "(//tr[@ng-click='vm.setCustomerRowIndex($index, customer)'])/td[1]")
    public static List<WebElement> getCustomerNamesList;

    @Name("Account Manager List")
    @FindBy(xpath = "(//tr[@ng-click='vm.setCustomerRowIndex($index, customer)'])/td[2]")
    public static List<WebElement> getAccountManagerList;

    @Name("Contact Persons List")
    @FindBy(xpath = "(//tr[@ng-click='vm.setCustomerRowIndex($index, customer)'])/td[3]")
    public static List<WebElement> getContactPersonsList;

    @Name("Region List")
    @FindBy(xpath = "(//tr[@ng-click='vm.setCustomerRowIndex($index, customer)'])/td[4]")
    public static List<WebElement> getRegionList;

    public void selectAddCustomer(String option) throws InterruptedException {
        if (option.equals("addCutomer")) {
            Actions.execJavascript("arguments[0].scrollIntoView()", addCustomer);
            Actions.execJavascript("arguments[0].click()", addCustomer);
        } else {
            Actions.execJavascript("arguments[0].scrollIntoView()", addIcon);
            Actions.execJavascript("arguments[0].click()", addIcon);
        }
    }

    public void selectEditCustomerButton() {
        Actions.execJavascript("arguments[0].scrollIntoView()", editIcon);
        Actions.execJavascript("arguments[0].click()", editIcon);
    }

    public void searchWithLatestCreatedCustomerName(String customer) throws InterruptedException {
        Thread.sleep(1000);
        Actions.execJavascript("arguments[0].scrollIntoView()", customersSearch);
        Actions.execJavascript("arguments[0].click()", customersSearch);
        customersSearch.sendKeys(customer);
        Actions.execJavascript("arguments[0].scrollIntoView()", searchButton);
        Actions.execJavascript("arguments[0].click()", searchButton);
        log().info("Searched with latest created customer" + customer);
    }

    public List<WebElement> getAllCustomerRowsFromResults() {
        return getCustomerRecordRows;
    }

    public WebElement getParticularRowFromResults(String requiredCustomerName) {
        WebElement custName = null;
        if (!getCustomerRecordRows.equals(null)) {
            for (WebElement ele : getCustomerRecordRows) {
                if (ele.getText().contains(requiredCustomerName)) {
                    custName = ele;
                }
            }
        }
        return custName;
    }

    public String getParticularCustomerNameFromResults(String requiredCustomerName) {
        String custName = null;
        if (!getCustomerNamesList.equals(null)) {
            for (WebElement ele : getCustomerNamesList) {
                if (ele.getText().equals(requiredCustomerName)) {
                    custName = ele.getText();
                }
            }
        }
        return custName;
    }

    public List<String> getAllCustomerNamesFromResults() {
        List<String> allCustomerNamesList = new ArrayList<>();
        if (!getCustomerNamesList.equals(null)) {
            for (WebElement ele : getCustomerNamesList) {
                allCustomerNamesList.add(ele.getText());
            }
        }
        return allCustomerNamesList;
    }
}
