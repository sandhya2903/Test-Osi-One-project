package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.TextInput;
import test.automation.framework.Config;
import test.automation.framework.Page;

public class ProjectsListPage extends Page {

    public static final String URL = Config.getUrl() + "/a1/#/projectsList";
    public static final By VERIFY_BY = By.name("searchProjectName");

    @Name("Save Button")
    @FindBy(xpath = "//button[contains(text(),'Add Project')]")
    public static Button addProject;

    @Name("Search Bar")
    @FindBy(name = "searchProjectName")
    public static TextInput searchBar;

    @Name("Search Button")
    @FindBy(xpath = "(//button[contains(text(),'Search')])[2]")
    public static Button searchButton;

    @Name("Project Name")
    @FindBy(xpath = "(//td[@class='ng-binding'])[1]")
    public static WebElement projNameIndex;
}
