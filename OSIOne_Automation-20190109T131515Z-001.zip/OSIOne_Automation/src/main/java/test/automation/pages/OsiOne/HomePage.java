package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.Link;
import ru.yandex.qatools.htmlelements.element.TextBlock;
import test.automation.framework.Actions;
import test.automation.framework.Config;
import test.automation.framework.Page;

import java.util.List;


public class HomePage extends Page {

    public static final String URL = Config.getUrl() + "/a1/#/dashboard";
    public static final By VERIFY_BY = By.linkText("Logout");

    @Name("PMO ADMIN")
    @FindBy(xpath = "//a[contains(text(),'PMO Admin')]")
    public static WebElement pmoAdmin;

    @Name("Customers")
    @FindBy(xpath = "//a[contains(text(),'Customers')]")
    public static WebElement customers;

    @Name("Projects")
    @FindBy(xpath = "//a[contains(text(),'Projects')]")
    public static WebElement projects;

    @Name("Toggle Bar")
    @FindBy(id = "toggle-btn")
    public static Button toggleButton;

    @Name("New Timesheet")
    @FindBy(xpath = "//*[@ng-click='vm.newtimeSheet()']")
    public static Link newTimeSheets;

    @Name("add TimeSheet")
    @FindBy(id = "addWeeklyEntryBtn")
    public static Button addTimesheet;

    @Name("Leaves")
    @FindBy(xpath = "//a[contains(text(),'Leaves')]")
    public static Link leavesButton;

    @Name("My Leaves Button")
    @FindBy(xpath = "//a[contains(text(),'My Leaves')]")
    public static Link myLeavesLinkButton;

    @Name("Leave Approvals")
    @FindBy(xpath = "//a[contains(text(),'Leave Approvals')]")
    public static Link leavesApprovalButton;

    @Name("Expenses")
    @FindBy(xpath = "(//*[contains(text(),\"Expenses\")])[1]")
    public static Link expensesLink;

    @Name("Expenses Link 2")
    @FindBy(xpath = "(//*[contains(text(),\"Expenses\")])[2]")
    public static Link expensesLink2;

    @Name("Expenses Link 3")
    @FindBy(xpath = "//*[contains(text(),\"Expense Approval\")]")
    public static Link expensesLink3;

    @Name("overdue link")
    @FindBy(xpath = "//*[@class='table  table-hover']//tr//td")
    public static List<WebElement> overdue;

    @Name("Timesheets")
    @FindBy(xpath = "//a[starts-with(text(),'Timesheets')]")
    public static Link timesheetsLinkButton;

    @Name("My Timesheets")
    @FindBy(xpath = "//a[contains(text(),'My Timesheets')]")
    public static Link myTimeSheetsLinkButton;

    @Name("Timesheet Approval")
    @FindBy(xpath = "//a[contains(text(),'Timesheet Approval')]")
    public static Link myTimeSheetApproval;

    @Name("Dashboard")
    @FindBy(css = "#dashboard > a")
    public static Link dashboard;

    @Name("My Profile")
    @FindBy(css = "#profile > a")
    public static Link myProfile;

    public static void navigateToCustomerPage() throws InterruptedException {
//        Actions.waitUntil(() -> toggleButton.isDisplayed());
//        toggleButton.click();
        Actions.execJavascript("arguments[0].scrollIntoView()", pmoAdmin);
        Actions.execJavascript("arguments[0].click()", pmoAdmin);
        Actions.execJavascript("arguments[0].scrollIntoView()", customers);
        Actions.execJavascript("arguments[0].click()", customers);
    }

    public static void navigateToProjectsPage() throws InterruptedException {
//        Actions.waitUntil(() -> toggleButton.isDisplayed());
//        toggleButton.click();
        Actions.execJavascript("arguments[0].scrollIntoView()", pmoAdmin);
        Actions.execJavascript("arguments[0].click()", pmoAdmin);
        Actions.execJavascript("arguments[0].scrollIntoView()", projects);
        Actions.execJavascript("arguments[0].click()", projects);
    }

    public static void navigateToLeavesPage() throws InterruptedException {
//        Actions.waitUntil(() -> toggleButton.isDisplayed());
//        toggleButton.click();
        Actions.execJavascript("arguments[0].scrollIntoView()", leavesButton);
        Actions.execJavascript("arguments[0].click()", leavesButton);
        Actions.execJavascript("arguments[0].scrollIntoView()", myLeavesLinkButton);
        Actions.execJavascript("arguments[0].click()", myLeavesLinkButton);
    }

    public static void navigateToLeavesApprovalPage() throws InterruptedException {
//        Actions.waitUntil(() -> toggleButton.isDisplayed());
//        toggleButton.click();
        Actions.execJavascript("arguments[0].scrollIntoView()", leavesButton);
        Actions.execJavascript("arguments[0].click()", leavesButton);
        Actions.execJavascript("arguments[0].scrollIntoView()", leavesApprovalButton);
        Actions.execJavascript("arguments[0].click()", leavesApprovalButton);
    }

    public static void navigateToExpensesPage() throws InterruptedException {
//        Actions.waitUntil(() -> toggleButton.isDisplayed());
//        toggleButton.click();
        Actions.execJavascript("arguments[0].scrollIntoView()", expensesLink);
        Actions.execJavascript("arguments[0].click()", expensesLink);
        Actions.execJavascript("arguments[0].scrollIntoView()", expensesLink2);
        Actions.execJavascript("arguments[0].click()", expensesLink2);
    }

    public static void navigateToExpensesApprovalPage() throws InterruptedException {
//        Actions.waitUntil(() -> toggleButton.isDisplayed());
//        toggleButton.click();
        Actions.execJavascript("arguments[0].scrollIntoView()", expensesLink);
        Actions.execJavascript("arguments[0].click()", expensesLink);
        Actions.execJavascript("arguments[0].scrollIntoView()", expensesLink3);
        Actions.execJavascript("arguments[0].click()", expensesLink3);
    }

    public static void navigateToTimeSheets() throws InterruptedException {
        Actions.execJavascript("arguments[0].scrollIntoView()", timesheetsLinkButton);
        Actions.execJavascript("arguments[0].click()", timesheetsLinkButton);
        Actions.execJavascript("arguments[0].scrollIntoView()", myTimeSheetApproval);
        Actions.execJavascript("arguments[0].click()", myTimeSheetApproval);

    }

    public static void navigateMyTimeSheets() throws InterruptedException {
        Actions.execJavascript("arguments[0].scrollIntoView()", timesheetsLinkButton);
        Actions.execJavascript("arguments[0].click()", timesheetsLinkButton);
        Actions.execJavascript("arguments[0].scrollIntoView()", myTimeSheetsLinkButton);
        Actions.execJavascript("arguments[0].click()", myTimeSheetsLinkButton);

    }
}
