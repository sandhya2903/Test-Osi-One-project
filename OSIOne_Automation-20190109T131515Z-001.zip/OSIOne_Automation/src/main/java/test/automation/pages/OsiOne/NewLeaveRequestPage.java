package test.automation.pages.OsiOne;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.*;
import ru.yandex.qatools.htmlelements.element.Button;
import test.automation.framework.Actions;
import test.automation.framework.Browser;
import test.automation.framework.Config;
import test.automation.framework.Page;

import java.util.*;
import java.util.List;
import java.util.stream.Collectors;


/**
 * Created by vemanepalli on 20-Sep-18.
 */
public class NewLeaveRequestPage extends Page {
    public static final String URL = Config.getUrl() + "/a5/#/leaves/leaverequest";
    public static final By VERIFY_BY = By.xpath("//h1[contains(text(),'New Leave Request')]");
    public static List<HashMap<String, WebElement>> userTable = new ArrayList<HashMap<String, WebElement>>();
    public static List<WebElement> rowElements;
    public static List<WebElement> row_table;
    public static WebElement leaveId;
    public static String leaveIdText;
    public static List<WebElement> reqRow;
    public static String storeStartDate;

    @Name("From Date")
    @FindBy(xpath = "(//*[@class='fa fa-lg fa-calendar'])[1]")
    public static WebElement fromDateCalendar;

    @Name("From Date TextBox Value")
    @FindBy(id = "fromDate")
    public static TextInput fromDateTextBoxValue;

    @Name("End Date Calendar")
    @FindBy(xpath = "(//*[@class='fa fa-lg fa-calendar'])[2]")
    public static WebElement endDateCalendar;

    @Name("Leave Types")
    @FindBy(id = "leaveTypeId")
    public static Select leaveTypeId;

    @Name("Leave Reason")
    @FindBy(name = "leaveReason")
    public static TextBlock leaveTypeReason;

    @Name("Upload File")
    @FindBy(name = "uploadfile")
    public static TextInput uploadFile;

    @Name("Save Button")
    @FindBy(xpath = "(//button[contains(text(),'Save')])[1]")
    public static Button saveButton;

    @Name("Leave Request Message")
    @FindBy(xpath = "//*[contains(text(),'Leave Request Created Successfully')]")
    public static TextBlock leaveRequestSuccessMessage;

    @Name("Leave Request Cancelled Successfully Message")
    @FindBy(xpath = "//*[contains(text(),'Leave Request Cancelled Successfully')]")
    public static TextBlock leaveRequestCancelledSuccessfullyMessage;

    @Name("table data")
    @FindBy(xpath = "//table[@class='table table-striped table-sm']/tbody")
    public static WebElement tableData;

    @Name("Save & Submit Button")
    @FindBy(xpath = "//button[contains(text(),'Save & Submit')]")
    public static Button saveSubmitButton;

    @Name("Yes pou up button")
    @FindBy(xpath = "(//button[contains(text(),'Yes')])[1]")
    public static Button confirmationYesPop;

    @Name("Cancel Button Yes Button Operations")
    @FindBy(xpath = "(//button[contains(text(),'Yes')])[2]")
    public static Button cancelYesButtonPopup;

    @Name("Leave Save Message")
    @FindBy(xpath = "//*[contains(text(),'Leave Request Created Successfully')]")
    public static TextBlock leaveSaveMessage;

    @Name("Leave Submit Message")
    @FindBy(xpath = "//*[contains(text(),'Leave Request Submitted Successfully')]")
    public static TextBlock leaveSucessMessage;

    @Name("Cancel Leave Button")
    @FindBy(xpath = "(//button[contains(text(),'Cancel Leave')])[2]")
    public static Button cancelLeaveButton;

    @Name("Cancel Leave Button")
    @FindBy(xpath = "(//button[contains(text(),'Cancel Leave')])[1]")
    public static Button cancelLeaveButtonEditLeaveRequestPage;

    @Name("Reason for cancellation")
    @FindBy(xpath = "//*[@id=\"cancelApprovedLeave\"]/div/form/div/div/div/form/textarea")
    public static TextBlock reasonForCancellation;

    @Name("Cancel Leave Request Yes Popup Button")
    @FindBy(xpath = "(//button[contains(text(),'Yes')])[3]")
    public static Button cancleReasonYesPopUpButton;

    @Name("Time Sheet Already Submitted Close Button")
    @FindBy(xpath = "//*[@id=\"errorMessage\"]/div/a")
    public static Link timeSheetAlreadySubmittedCloseButton;

    @Name("Time Sheet Already Submitted popup Message")
    @FindBy(xpath = "//*[@id=\"errorMessage\"]/div")
    public static WebElement timeSheetPopUpMessage;

    @Name("Calender Arrow Button")
    @FindBy(xpath = "(//span[@class='ngb-dp-navigation-chevron'])[2]")
    public static Button calenderArrowButton;

    public static String cancellationReason;

    @Name("Leave Id Arrow Button")
    @FindBy(xpath = "(//span[@class='glyphicon sort-icon glyphicon-chevron-down'])[1]")
    public static WebElement leaveIdArrowButton;


    public static void randomDate() {
        calenderArrowButton.click();
        java.util.List<WebElement> dates = Browser.getDriver().findElements(By.xpath("//*[@class=\"btn-light\"]"));
        WebElement randomselect = dates.get(new Random().nextInt(dates.size() - 1));
        Actions.execJavascript("arguments[0].scrollIntoView();", randomselect);
        Actions.execJavascript("arguments[0].click();", randomselect);
    }

    public static void calendarStartDate() throws InterruptedException {
        Actions.execJavascript("arguments[0].click();", fromDateCalendar);
        //fromDateCalendar.click();
        randomDate();
        storeStartDate = fromDateTextBoxValue.getAttribute("value");
    }

    public static void calendarEndDate() throws InterruptedException {
        // Actions.execJavascript("arguments[0].click();", endDateCalendar);
        endDateCalendar.click();
        randomDate();

    }

    public void selectLeaveTypes() throws InterruptedException {
        leaveTypeId.selectByVisibleText("PAID TIME OFF (PTO)");
        Actions.waitUntil(() -> leaveTypeId.isDisplayed(), 2000);

    }

    public static void purposeLeaveReason(String leave_type) throws InterruptedException {
        String leaveReason = null;
        switch (leave_type.trim()) {
            case "BEREAVEMENT":
                leaveReason = " Applying for BEREAVEMENT Leaves";
                break;
            case "MARRIAGE":
                leaveReason = " Applying for MARRIAGE Leaves";
                break;
            case "MATERNITY":
                leaveReason = " Applying for MATERNITY Leave";
                break;
            case "PAID TIME OFF (PTO)":
                leaveReason = " Applying for PTO Leave";
                break;
            case "PATERNITY":
                leaveReason = " Applying for PATERNITY Leave";
                break;
        }
        leaveTypeReason.sendKeys(leaveReason);
    }

    public static void saveButtonOperation() throws InterruptedException {
        if (!saveButton.isEnabled()) {
            calendarStartDate();
            calendarEndDate();
        }

        Actions.execJavascript("arguments[0].click();", saveButton);
        Thread.sleep(2000);
        Assert.assertTrue("Leave Message not Successfully Saved", leaveSaveMessage.isDisplayed());
    }

    public void statusVerify(WebElement tableData, String status) throws InterruptedException {
        row_table = tableData.findElements(By.tagName("tr"));
        List<WebElement> reqRow = row_table.stream().filter(a -> a.getText().contains(status)).collect(Collectors.toList());
        switch (status) {
            case "Open":
                Assert.assertTrue("Open status not displayed", reqRow.get(0).getText().contains(status));
                break;
            case "Approved":
                Assert.assertTrue("Approved status not displayed", reqRow.get(0).getText().contains(status));
                break;
            case "Submitted":
                Assert.assertTrue("Submitted status not displayed", reqRow.get(0).getText().contains(status));
                break;
            case "Submitted for Cancel":
                Assert.assertTrue("Submitted for Cancel status not displayed",
                        reqRow.get(0).getText().contains(status));
                break;
            case "Cancelled":
                Assert.assertTrue("Cancelled for Cancel status not displayed",
                        reqRow.get(0).getText().contains(status));
                break;
            case "Rejected":
                Assert.assertTrue("Rejected status not displayed",
                        reqRow.get(0).getText().contains(status));
                break;
        }
    }

    public static void doubleClickOnStatus(WebElement tableData, String status) throws InterruptedException {
        row_table = tableData.findElements(By.tagName("tr"));
        List<WebElement> reqRow = row_table.stream().filter(a -> a.getText().contains(leaveIdText)).collect(Collectors.toList());
        if (reqRow.get(0).getText().contains(status)) {
            Actions.doubleClick(reqRow.get(0));
            Thread.sleep(3000);
        }

    }

    public void getLeavesList(WebElement tableData) throws InterruptedException {
        row_table = tableData.findElements(By.tagName("tr"));
        for (WebElement tr_element : row_table) {
            if (tr_element.getText().contains(storeStartDate)) {
                leaveId = tr_element.findElement(By.xpath("(//td)[1]"));
                leaveIdText = leaveId.getText();
                Actions.doubleClick(leaveId);
                Thread.sleep(3000);
                break;
            }

        }
        saveSubmitButton.click();
        Actions.waitUntil(() -> confirmationYesPop.isDisplayed(), 2000);
        Actions.execJavascript("arguments[0].click();", confirmationYesPop);
        Assert.assertTrue("Leave Request not Successfully Created", leaveSucessMessage.isDisplayed());
    }

    public static void cancelButtonOperation() throws InterruptedException {
        Actions.execJavascript("arguments[0].click();", cancelLeaveButton);
        //cancelLeaveButton.click();
        cancellationReason = "Postoponed Leave";
        Thread.sleep(2000);
        reasonForCancellation.sendKeys(cancellationReason);
        Actions.execJavascript("arguments[0].click();", cancleReasonYesPopUpButton);
        //cancleReasonYesPopUpButton.click();
        // Actions.waitUntil(() -> !cancelYesButtonPopup.isDisplayed(), 3000);
        //Actions.execJavascript("arguments[0].click();", cancelYesButtonPopup);
    }

    public static void employeeCancelLeaveOpetaion() throws InterruptedException {
        Actions.execJavascript("arguments[0].click();", cancelLeaveButtonEditLeaveRequestPage);
        Actions.waitUntil(() -> cancelYesButtonPopup.isDisplayed(), 2000);
        Actions.execJavascript("arguments[0].click();", cancelYesButtonPopup);
        Actions.waitUntil(() -> leaveRequestCancelledSuccessfullyMessage.isDisplayed(), 2000);
        Assert.assertTrue("Leave Request Cancelled Successfully is not displayed",
                leaveRequestCancelledSuccessfullyMessage.isDisplayed());
    }


}
