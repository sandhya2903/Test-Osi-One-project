package test.automation.pages.OsiOne;

import groovyjarjarantlr.collections.impl.LList;
import org.apache.http.Header;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.*;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.*;
import ru.yandex.qatools.htmlelements.element.Select;
import test.automation.framework.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by amolleti on 9/7/2018.
 * Mandatory field data is Invalid - Project Name
 */
public class ProjectsPage extends Page {

    public static final String URL = Config.getUrl() + "/a1/#/projects";
    public static final By VERIFY_BY = By.linkText("Projects");

    public static String StartDate;
    public static String EndDate;
    public static String projName;
    public static String projDescription;
    public static String projectManagerName;
    public static String salesContactPerson;
    public static String cusName;
    public static String Currency;
    public static String ProjectType;
    public static String ProjectStatus;
    public static String CustomerContact;
    public static String Locations;
    public static String TaxLocation;
    public static List<String> ActivityNames;
    public static String EmployeName;
    public static String EmployeRole;
    public static List<HashMap<String, WebElement>> userTable = new ArrayList<HashMap<String, WebElement>>();
    public static List<WebElement> rowElements = new ArrayList<>();
    public static List<String> ActivitiesList = new ArrayList<>();
    public static List<String> TaskNames = new ArrayList<>();

    ;
//    public static List<WebElement> rowElements;

    @Name("Project Name")
    @FindBy(id = "projName")
    public TextInput projectName;

    @Name("Project description")
    @FindBy(id = "projectDescription")
    public TextInput projectDescription;

    @Name("Start Date")
    @FindBy(name = "projectStartDate")
    public TextBlock startDate;

    @Name("End Date")
    @FindBy(name = "projectEndDate")
    public TextBlock endtDate;

    @Name("Next Page")
    @FindBy(xpath = "(//a[@title='Next'])[2]")
    public WebElement nextPage;

    @Name("Currency")
    @FindBy(id = "currency")
    public Select currency;

    @Name("Deparment")
    @FindBy(id = "department")
    public WebElement department;

    @Name("Organization")
    @FindBy(id = "orgProjectName0")
    public Select organization;

    @Name("Region")
    @FindBy(id = "orgProjectName1")
    public Select region;

    @Name("BusinessUnit")
    @FindBy(id = "orgProjectName2")
    public Select bussinessUnit;

    @Name("Practice")
    @FindBy(id = "orgProjectName3")
    public Select practice;

    @Name("SubPractice")
    @FindBy(id = "orgProjectName4")
    public Select subPractice;

    @Name("Group")
    @FindBy(id = "orgProjectName5")
    public Select group;

    @Name("CostCenter")
    @FindBy(id = "orgProjectName6")
    public Select costCeneter;

    @Name("Department Details submit")
    @FindBy(xpath = "(//button[contains(text(),\"OK\")])[3]")
    public Button departmentDetailsSubmit;

    @Name("ProjectManager")
    @FindBy(id = "projectManager")
    public TextInput projectManager;

    @Name("Salesperson")
    @FindBy(id = "salesPerson")
    public TextInput salesPerson;

    @Name("Review Note")
    @FindBy(id = "projectReviewNotes")
    public TextInput reviewNote;

    @Name("CustomerContacts")
    @FindBy(id = "customerContacts")
    public Select customerContact;

    @Name("SourcedForm")
    @FindBy()
    public TextInput sourcedForm;

    @Name("CustomerName")
    @FindBy(id = "customerName")
    public Select customerName;

    @Name("Customer Name view")
    @FindBy(xpath = "//label[contains(text(),\"Customer Name\")]")
    public WebElement customerNameView;

    @Name("ProjectLongName")
    @FindBy(id = "projLongName")
    public TextInput projectLongName;

    @Name("ProjectType")
    @FindBy(id = "projectType")
    public Select projectType;

    @Name("ProjectStatus")
    @FindBy(id = "projectStatus")
    public Select projectStatus;

    @Name("Technologies")
    @FindBy()
    public TextInput technologies;

    @Name("Locations")
    @FindBy(id = "location")
    public Select locations;

    @Name("Other Department Services")
    @FindBy(id = "department")
    public TextInput departmentServices;

    @Name("InvoiceTemplate")
    @FindBy(id = "invoicetemplate")
    public Select invoiceTemplete;

    @Name("TaxLocation")
    @FindBy(id = "taxLocation")
    public Select taxlocations;

    @Name("StatIONumber")
    @FindBy(id = "ioNumber")
    public Select statIoNumber;

    @Name("Save Button")
    @FindBy(xpath = "//button[contains(text(),'Save')]")
    public Button saveButton;

    @Name("Employee Label")
    @FindBy(id = "employeeSearchNamePro")
    public WebElement empListLabel;

    @Name("Employee List")
    @FindBy(xpath = "//span[@class='form-control-static']")
    public List<WebElement> employeelist;

    @Name("Billable")
    @FindBy(xpath = "//input[@id='billable']")
    public CheckBox billable;

    @Name("Expense Billable")
    @FindBy(xpath = "//input[@id='billableExpense']")
    public CheckBox expenseBillable;

    @Name("Internal")
    @FindBy(xpath = "//input[@id='internal']")
    public CheckBox internal;

    @Name("Visiable All")
    @FindBy(xpath = "//input[@id='visibleAll']")
    public CheckBox visiableAll;

    @Name("Error Message")
    @FindBy(xpath = "//div[contains(text(),'Mandatory field data is Invalid - Project Name')]")
    public WebElement errorMessage;

    @Name("Customer error Message")
    @FindBy(xpath = "//div[contains(text(),'Mandatory field data is Invalid - Customer Contacts')]")
    public WebElement contactErrorMessage;

    @Name("Customer error Message")
    @FindBy(xpath = "//div[contains(text(),'Mandatory field data is Invalid - Project Type')]")
    public WebElement projectTypeErrorMessage;

    @Name("Customer error Message")
    @FindBy(xpath = "//div[contains(text(),'Mandatory field data is Invalid - Project Status')]")
    public WebElement peojectStatusErrorMessage;

    @Name("Message")
    @FindBy(xpath = "//div[contains(text(),'Project Saved Successfully')]")
    public WebElement message;

    //Commercial Tab Locators

    @Name("Commercial Tab")
    @FindBy(id = "sowTab")
    public WebElement commericalTab;

    @Name("SOW Start Date")
    @FindBy(name = "sowStartDate")
    public TextInput sowStartDate;

    @Name("SOW End Date")
    @FindBy(name = "sowEndDate")
    public TextInput sowEndDate;

    @Name("Sow Types")
    @FindBy(id = "SowTypes")
    public Select sowTypes;

    @Name("Add SOW")
    @FindBy(xpath = "//button[contains(text(), 'Add SOW')]")
    public Button addSow;

    @Name("Select SOW")
    @FindBy(xpath = "//select[@id='SowTypes']/option")
    public WebElement selectSow;

    @Name("SOW Number")
    @FindBy(id = "sowNumber")
    public TextInput sowNumber;

    @Name("SOW Type")
    @FindBy(id = "sowType")
    public Select sowType;

    @Name("Budget Hours")
    @FindBy(id = "sowHours")
    public TextInput sowHours;

    @Name("Budget Money")
    @FindBy(xpath = "//input[@ng-model='vm.projectSow.sowAmount']")
    public TextInput budgetMoney;

    @Name("Budget Cost")
    @FindBy(xpath = "//input[@ng-model='vm.projectSow.budgetCost']")
    public TextInput budgetCost;

    @Name("SOW Billing Type")
    @FindBy(id = "sowBillingType")
    public Select sowBillingType;

    @Name("PO Number")
    @FindBy(name = "poNumber")
    public TextInput poNumber;

    @Name("SOW Margin")
    @FindBy(id = "sowMargin")
    public TextInput sowMargin;

    @Name("Activity Name")
    @FindBy(id = "activityName_0")
    public TextInput activityName;

    @Name("Activity Hours")
    @FindBy(id = "hours_0")
    public TextInput activityHours;

    @Name("Activity Cost")
    @FindBy(id = "cost")
    public TextInput activityCost;

    @Name("Activities Container")
    @FindBy(name = "tasksContainerFluid")
    public Table activitiesContainer;

    @Name("Activities List")
    @FindBy(xpath = "//tr[@ng-repeat='task in vm.projectSow.osiSowActivitiesTemp track by $index']")
    public List<WebElement> activitiesList;

    @Name("Milestone Container")
    @FindBy(id = "data")
    public Table milestoneContainer;

    @Name("MileStones List")
    @FindBy(id = "milestoneList")
    public List<WebElement> milestonesList;

    @Name("Commercials Save Button")
    @FindBy(xpath = "(//*[contains(text(),'Save')])[3]")
    public Button comercialsSaveButton;

    @Name("Commercials Cancel Button")
    @FindBy(xpath = "//button[contains(text(), 'Cancel')]")
    public Button comercialsCancelButton;

    @Name("SOW Next Page")
    @FindBy(xpath = "(//b[@class='_720kb-datepicker-default-button'])[22]")
    public WebElement sowNextPage;

    @Name("Commercial updated message")
    @FindBy(xpath = "//div[contains(text(),'Commercials saved successfully')]")
    public WebElement commercialUpdatedMessage;

    @Name("Commercial activities list")
    @FindBy(xpath = "//*[contains(@id,'activityName_')]")
    public List<WebElement> activitiesNamesList;

    //Resources Elements
    @Name("Resources Tab")
    @FindBy(xpath = "//*[@id=\"navbar\"]/ul/li[3]/a")
    public Link resourcesTab;

    @Name("ADD Resources")
    @FindBy(xpath = "(//*[@class='ng-scope']/i)[1]")
    public WebElement addResources;

    @Name("Edit Resources")
    @FindBy(xpath = "(//*[@class='ng-scope']/i)[2]")
    public WebElement editResources;

    @Name("view Resources")
    @FindBy(xpath = "(//*[@class='ng-scope']/i)[3]")
    public WebElement viewResources;

    @Name("Delete Resources")
    @FindBy(xpath = "(//*[@class='ng-scope']/i)[4]")
    public WebElement deleteResources;

    @Name("Project Name")
    @FindBy(name = "projectName")
    public TextBlock resourceProjectName;

    @Name("Employee Name")
    @FindBy(id = "resourceName")
    public TextInput employeeName;

    @Name("Role")
    @FindBy(id = "empRole")
    public Select role;

    @Name("Resource Cost")
    @FindBy(name = "resourceCost")
    public TextInput resourceCost;

//    @Name("Resource Start Date")
//    @FindBy(id = "resourceStartDate")
//    public WebElement resourceStartDate;
//
//    @Name("Resource End Date")
//    @FindBy(id = "resourceEndDate")
//    public WebElement resourceEndDate;

    @Name("Resource billable")
    @FindBy(id = "billable")
    public CheckBox resourceBillable;

    @Name("Resource roles list")
    @FindBy(xpath = "//*[@id='empRole']/option")
    public List<WebElement> emprolelist;

    @Name("Add resource save button")
    @FindBy(xpath = "(//*[contains(text(),'Save')])[2]")
    public Button addResourcesave;

    @Name("Add Resource Message")
    @FindBy(xpath = "//div[contains(text(),'Project Saved Successfully')]")
    public TextBlock addResourceMessage;

    @Name("Resource saved message")
    @FindBy(xpath = "//div[contains(text(),'Resource Saved Successfully')]")
    public TextBlock resourceSavedMessage;

    @Name("Resource Table")
    @FindBy(xpath = "(//table[@class='table table-striped table-sm'])[1]")
    public TextBlock resourceTable;

    @Name("Resource Name")
    @FindBy(xpath = "//*[@id=\"resources\"]//tbody/tr/td[1]")
    public TextBlock resourceName;

    @Name("Resource role")
    @FindBy(xpath = "//*[@id=\"resources\"]//tbody/tr/td[2]")
    public TextBlock resourceRole;

    @Name("Resource Name Header")
    @FindBy(xpath = "//*[@id=\"resources\"]//th[1]")
    public Table resourceHeaderName;

    @Name("Resource role Header")
    @FindBy(xpath = "//*[@id=\"resources\"]//th[2]")
    public Table resourceHeaderRole;

    @Name("Resource StartDate Header")
    @FindBy(xpath = "//*[@id=\"resources\"]//th[3]")
    public Table resourceHeaderStartDate;

    @Name("Resource EndDate Header")
    @FindBy(xpath = "//*[@id=\"resources\"]//th[4]")
    public Table resourceHeaderEndDate;

    @Name("Billable Header")
    @FindBy(xpath = "//*[@id=\"resources\"]//th[5]")
    public Table billableHeader;

    @Name("Delete Resource")
    @FindBy(xpath = "(//span[@ng-if=\"vm.editProjectPage\"]/i)[4]")
    public WebElement resourceDelete;

    @Name("Resource Delete Confirmation popup")
    @FindBy(xpath = "//*[@id=\"resourceDeletionModal\"]//h4")
    public WebElement resourceDeletePopup;

    @Name("Resource Delete Confirmation")
    @FindBy(xpath = "(//button[contains(text(),\"Yes\")])[9]")
    public Button resourceDeleteConfirmation;

    @Name("No records found")
    @FindBy(xpath = "//*[@id=\"resources\"]//h6")
    public WebElement noRecordsFound;

    //Project Plan
    @Name("Project Plan Tab")
    @FindBy(xpath = "(//*[@id=\"tasksTab\"])[1]")
    public Link projectPlanTab;

    @Name("Project Plan TaskName")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[1]")
    public Table projectTaskNameHeader;

    @Name("Project Plan TaskType")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[2]")
    public Table projectTaskTypeHeader;

    @Name("Project Plan Activity")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[3]")
    public Table projectActivity;

    @Name("Project Plan Parent Task")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[4]")
    public Table projectParentTask;

    @Name("Project Plan Predecessor Task")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[5]")
    public Table projectPredecessorTask;

    @Name("Project Plan Assigned Resources")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[6]")
    public Table projectAssignedResources;

    @Name("Project Plan Estimated Hours")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[7]")
    public Table projectEstimatedHours;

    @Name("Project Plan Actual Hours")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[8]")
    public Table projectActualHours;

    @Name("Project Plan Task")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[9]")
    public Table projectTask;

    @Name("Project Plan StartDate")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[10]")
    public Table projectStartDate;

    @Name("Project Plan EndDate")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[11]")
    public Table projectEndDate;

    @Name("Project Plan MileStone")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[12]")
    public Table projectMileStone;

    @Name("Project Plan completed")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[13]")
    public Table projectCompleted;

    @Name("Project Plan Action")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]/form//th[14]")
    public Table projectAction;

    @Name("Assigned Resource")
    @FindBy(xpath = "(.//tr[@class='ng-scope']/td)[32]/a")
    public WebElement assignedResourceview;

    @Name("Resource Name")
    @FindBy(xpath = "(//*[@class=\"box-body table-responsive\"]//tr//td)[7]")
    public WebElement assignedResourceName;

    @Name("Action")
    @FindBy(xpath = "//*[@id=\"tasksContainerFluid\"]//th[14]")
    public WebElement actionsview;

    @Name("Project Plan Startdate")
    @FindBy(xpath = "(//datepicker/input)[1]")
    public WebElement ppStartDate;

    @Name("Project Plan Enddate")
    @FindBy(xpath = "(//datepicker/input)[2]")
    public WebElement ppEndDate;

    @Name("Project Task Type Dropdown")
    @FindBy(xpath = "(//*[@id='taskTypeId'])[1]")
    public Select pTaskType;

    @Name("Project Activity Dropdown")
    @FindBy(xpath = "(//*[@id='sowActivityId0'])[1]")
    public Select pActivity;

    @Name("Project Parent Task")
    @FindBy(xpath = "(//*[@id='parentTaskId'])[1]")
    public Select pParentTask;

    @Name("Project predecessor TaskId")
    @FindBy(xpath = "(//*[@id='predecessorTaskId'])[1]")
    public Select pPredecessorTaskId;

    @Name("Task Resource Assigned")
    @FindBy(xpath = "//*[@id=\"taskResourcesPageModal\"]//td[1]/input")
    public CheckBox pTaskResourceAssigned;

    @Name("Task Resource popup")
    @FindBy(xpath = "(//*[@id=\"taskResourcesPageModal\"]//button) [2]")
    public Button taskResourcePopup;

    @Name("Project Plan Save")
    @FindBy(xpath = "(//*[@id=\"projectplan\"]//button[contains(text(),\"Save\")])[1]")
    public Button projectPlanSave;

    @Name("Project Plan Saved Message")
    @FindBy(xpath = "//div[contains(text(),'Project Task Saved Successfully')]")
    public TextBlock projectPlanSavedMessage;

    public void randomDate(String dayType) {
        List<WebElement> dates = Browser.getDriver().findElements(By.xpath("//a[@ng-click='setDatepickerDay(item)']"));
        List<WebElement> range = dayType.equals("startDate") ? dates.subList(0, 29) : dates.subList(30, 59);
        WebElement randomselect = range.get(new Random().nextInt(range.size() - 1));
        Actions.execJavascript("arguments[0].scrollIntoView();", randomselect);
//        Actions.execJavascript("arguments[0].click();", randomselect);
        randomselect.click();
    }

    public void selectStartDate(String string) throws InterruptedException {
        WebElement e = string.equalsIgnoreCase("SOW") ? sowStartDate : startDate;
//        Actions.execJavascript("arguments[0].click();", e);
        e.click();
        randomDate("startDate");
        StartDate = startDate.getAttribute("value");
    }

    public void setCustomerName() {
        List<WebElement> e = Browser.getDriver().findElements(By.xpath("//select[@id='customerName']/option"));
        List<WebElement> s = e.stream().filter(a -> a.getText().startsWith("Automation")).collect(Collectors.toList());
        cusName = s.get(new Random().nextInt(s.size())).getText().toString();
        customerName.selectByVisibleText(cusName);
    }

    public void selectEndtDate(String string) throws InterruptedException {
        WebElement endDate = string.equalsIgnoreCase("SOW") ? sowEndDate : endtDate;
//        Actions.execJavascript("arguments[0].click();", endDate);
        endDate.click();
        WebElement nextMonth = string.equalsIgnoreCase("SOW") ? sowNextPage : nextPage;
//        Actions.execJavascript("arguments[0].click();", nextMonth);
//        Actions.execJavascript("arguments[0].click();", nextMonth);
        Actions.doubleClick(nextMonth);
        randomDate("endDate");
        EndDate = endDate.getAttribute("value");
    }

    public void activitesNameList(int k) {
        for (int i = 0; i <= k; i++) {
            Browser.getDriver().findElement(By.id("activityName_" + i)).sendKeys(Util.getRandomActivity());
            Browser.getDriver().findElement(By.id("hours_" + i)).sendKeys(test.automation.framework.Random.getRandomNumber(1));
            int j = 1 + i;
            Browser.getDriver().findElement(By.xpath("(//*[@id=\"cost\"])[" + j + "]")).sendKeys(test.automation.framework.Random.getRandomNumber(3));
        }
        ActivityNames = activitiesNamesList.stream().map(a -> a.getAttribute("value")).collect(Collectors.toList());
    }

    public String currency() {
        List<WebElement> elements = Browser.getDriver().findElements(By.xpath("//select[@id='currency']/option"));
        WebElement element = elements.get(new Random().nextInt(elements.size() - 1));
        String value = element.getAttribute("value");
        String currency = value.substring(7, 10);
        return currency;
    }

    public void departmentDetails() {
        department.click();
        organization.selectByVisibleText("OSIUS");
        region.selectByVisibleText("NA-CEN");
        bussinessUnit.selectByVisibleText("DLY");
        practice.selectByVisibleText("EA");
        subPractice.selectByVisibleText("CX");
        group.selectByVisibleText("SALESFORCE");
        costCeneter.selectByVisibleText("DLY.EA.CX.SALESFORCE.OSIUS");
//        Actions.execJavascript("arguments[0].click();", departmentDetailsSubmit);
        departmentDetailsSubmit.click();
    }

    public void customerDetails() {
        Actions.execJavascript("arguments[0].scrollIntoView();", customerName);
        customerName.selectByVisibleText(AddCustomerPage.custName);
        Actions.execJavascript("arguments[0].scrollIntoView();", departmentServices);
        dropDownSelection("customerContacts", customerContact);
        dropDownSelection("taxLocation", taxlocations);
    }

    public void dropDownSelection(String id, Select element) {
        List<WebElement> e = Browser.getDriver().findElements(By.xpath("//select[@id='" + id + "']/option"));
        List<String> l = e.stream().map(a -> a.getAttribute("label")).collect(Collectors.toList());
        l.remove(0);
        String randomSelect = l.get(new Random().nextInt(l.size()));
        element.selectByVisibleText(randomSelect);
    }

    public void projectManager() {
        String acctManager = Util.getRandomFirstName();
        projectManager.sendKeys(acctManager);
        projectManager.sendKeys(Keys.TAB);
        Actions.waitUntil(() -> empListLabel.isDisplayed(), 2000);
        String fullName = new AddCustomerPage().getAccuontManagerDetailsNames(acctManager);
        WebElement empNames = employeelist.stream().filter(a -> a.getText().equals(fullName)).collect(Collectors.toList()).get(0);
        projectManagerName = empNames.getText();
        Actions.doubleClick(empNames);
    }

    public void salesContactPerson() {
        String acctManager = Util.getRandomFirstName();
        salesPerson.sendKeys(acctManager);
        salesPerson.sendKeys(Keys.TAB);
        Actions.waitUntil(() -> empListLabel.isDisplayed(), 2000);
        String fullName = new AddCustomerPage().getAccuontManagerDetailsNames(acctManager);
        WebElement empNames = employeelist.stream().filter(a -> a.getText().equals(fullName)).collect(Collectors.toList()).get(0);
        salesContactPerson = empNames.getText();
        Actions.doubleClick(empNames);
    }

    public void setEmployeeName() {
        String acctManager = Util.getRandomFirstName();
        employeeName.sendKeys(acctManager);
        employeeName.sendKeys(Keys.TAB);
        Actions.waitUntil(() -> empListLabel.isDisplayed(), 2000);
        String fullName = new AddCustomerPage().getAccuontManagerDetailsNames(acctManager);
        WebElement empNames = employeelist.stream().filter(a -> a.getText().equals(fullName)).collect(Collectors.toList()).get(0);
        Actions.doubleClick(empNames);
        EmployeName = employeeName.getAttribute("value");
    }

    public void iEnterDetailsOfProject() throws InterruptedException {
        projName = Util.projectName(5);
        projectName.sendKeys(projName);
        projectDescription.sendKeys(Util.projectDescription(4));
        Thread.sleep(500);
        selectStartDate("");
        selectEndtDate("");
        currency.selectByVisibleText(currency());
        departmentDetails();
        projectManager();
        salesContactPerson();
        reviewNote.sendKeys("Better Service");
        Thread.sleep(500);
        Actions.execJavascript("arguments[0].scrollIntoView();", customerName);
        Actions.execJavascript("arguments[0].scrollIntoView();", customerNameView);
        setCustomerName();
        dropDownSelection("projectType", projectType);
        dropDownSelection("projectStatus", projectStatus);
        dropDownSelection("location", locations);
        Actions.execJavascript("arguments[0].scrollIntoView();", customerContact);
        Actions.waitUntilElementPresent(customerContact, 5);
        dropDownSelection("customerContacts", customerContact);
        dropDownSelection("taxLocation", taxlocations);
    }

    public void iEditDetailsOfProject() throws InterruptedException {
        projectName.clear();
        projName = Util.projectName(5);
        projectName.sendKeys(projName);
        projectDescription.clear();
        projDescription = Util.projectDescription(4);
        projectDescription.sendKeys(projDescription);
        Thread.sleep(1000);
        selectStartDate("");
        selectEndtDate("");
        dropDownSelection("currency", currency);
        Currency = currency.getFirstSelectedOption().getText();
//        currency.selectByVisibleText(currency());
        projectManager.clear();
        projectManager();
        salesPerson.clear();
        salesContactPerson();
        Actions.execJavascript("arguments[0].scrollIntoView();", customerName);
        setCustomerName();
        dropDownSelection("projectType", projectType);
        ProjectType = projectType.getFirstSelectedOption().getText();
        dropDownSelection("projectStatus", projectStatus);
        ProjectStatus = projectStatus.getFirstSelectedOption().getText();
        dropDownSelection("location", locations);
        Locations = locations.getFirstSelectedOption().getText();
        Actions.execJavascript("arguments[0].scrollIntoView();", customerContact);
        Actions.waitUntilElementPresent(customerContact, 5);
        dropDownSelection("customerContacts", customerContact);
        CustomerContact = customerContact.getFirstSelectedOption().getText();
        dropDownSelection("taxLocation", taxlocations);
        TaxLocation = taxlocations.getFirstSelectedOption().getText();
    }

    public void verifyEditDetails() {
        Actions.execJavascript("arguments[0].scrollIntoView();", projectName);
        Actions.waitUntil(() -> projectName.isDisplayed());
        Assert.assertTrue("", projName.equals(projectName.getText()));
        Assert.assertTrue("", projDescription.equals(projectDescription.getAttribute("value")));
        Assert.assertTrue("", StartDate.equals(startDate.getAttribute("value").toString()));
        Assert.assertTrue("", EndDate.equals(endtDate.getAttribute("value").toString()));
        Assert.assertTrue("", Currency.equals(currency.getFirstSelectedOption().getText()));
        Assert.assertTrue("", projectManagerName.equals(projectManager.getText().replaceAll("\\s+$", "")));
        Assert.assertTrue("", salesContactPerson.equals(salesPerson.getText().replaceAll("\\s+$", "")));
//        Actions.execJavascript("arguments[0].scrollIntoView();", customerName);
        Assert.assertTrue("", cusName.equals(customerName.getFirstSelectedOption().getText()));
        Assert.assertTrue("", ProjectType.equals(projectType.getFirstSelectedOption().getText()));
        Assert.assertTrue("", ProjectStatus.equals(projectStatus.getFirstSelectedOption().getText()));
        Assert.assertTrue("", Locations.equals(locations.getFirstSelectedOption().getText()));
        Actions.execJavascript("arguments[0].scrollIntoView();", customerContact);
        Assert.assertTrue("", CustomerContact.equals(customerContact.getFirstSelectedOption().getText()));
        Assert.assertTrue("", TaxLocation.equals(taxlocations.getFirstSelectedOption().getText()));


    }

    public void sowDetails() throws InterruptedException {
        sowNumber.sendKeys(Util.getRandomNumber(2));
        dropDownSelection("sowType", sowType);
        sowHours.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        budgetMoney.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        budgetCost.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        dropDownSelection("sowBillingType", sowBillingType);
        sowMargin.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        //Activity Details
        activityName.sendKeys(Util.getRandomActivity());
        activityHours.sendKeys(test.automation.framework.Random.getRandomNumber(1));
        activityCost.sendKeys(test.automation.framework.Random.getRandomNumber(3));
        Actions.execJavascript("arguments[0].scrollIntoView();", comercialsSaveButton);
//        Actions.execJavascript("arguments[0].click();", comercialsSaveButton);
        comercialsSaveButton.click();

    }

    public void multipleSows() {
        for (int i = 0; i <= 5; i++) {
            try {
                if (addSow.isDisplayed())
                    addSow.click();
            } catch (Exception e) {
                e.getMessage();
            }
            sowNumber.sendKeys(Util.getRandomNumber(2));
            dropDownSelection("sowType", sowType);
            sowHours.sendKeys(test.automation.framework.Random.getRandomNumber(2));
            budgetMoney.sendKeys(test.automation.framework.Random.getRandomNumber(2));
            budgetCost.sendKeys(test.automation.framework.Random.getRandomNumber(2));
            dropDownSelection("sowBillingType", sowBillingType);
            sowMargin.sendKeys(test.automation.framework.Random.getRandomNumber(2));
            //Activity Details
            activityName.sendKeys(Util.getRandomActivity());
            activityHours.sendKeys(test.automation.framework.Random.getRandomNumber(1));
            activityCost.sendKeys(test.automation.framework.Random.getRandomNumber(3));
            Actions.execJavascript("arguments[0].scrollIntoView();", comercialsSaveButton);
//            Actions.execJavascript("arguments[0].click();", comercialsSaveButton);
            comercialsSaveButton.click();
        }
    }

    public void multipleActivities() {
        sowNumber.sendKeys(Util.getRandomNumber(2));
        dropDownSelection("sowType", sowType);
        sowHours.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        budgetMoney.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        budgetCost.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        dropDownSelection("sowBillingType", sowBillingType);
        sowMargin.sendKeys(test.automation.framework.Random.getRandomNumber(2));
        //Activity Details
        activitesNameList(4);
        Actions.execJavascript("arguments[0].scrollIntoView();", comercialsSaveButton);
//        Actions.execJavascript("arguments[0].click();", comercialsSaveButton);
        comercialsSaveButton.click();
        activitiesList();
    }

    public void activitiesList() {
        for (int i = 1; i <= 5; i++) {
            WebElement rowElement = Browser.getDriver().findElement(By.xpath("(//*[@class='table'])[1]/tbody/tr[" + i + "]/td[1]/input"));
            ActivitiesList.add(rowElement.getAttribute("value"));
        }
    }

    public void addResources() throws InterruptedException {
//        Actions.execJavascript("arguments[0].click();", resourcesTab);
        resourcesTab.click();
//        Actions.execJavascript("arguments[0].click();", addResources);
        addResources.click();
        Thread.sleep(2000);
        setEmployeeName();
        dropDownSelection("empRole", role);
        String s = role.getText();
        EmployeRole = s.substring(10, s.length());
        resourceCost.sendKeys(Util.getRandomNumber(3));
        addResourcesave.click();
    }

    public void projectPlanTaskNamesList() {
        for (int i = 1; i <= 5; i++) {
            WebElement rowElement = Browser.getDriver().findElement(By.xpath("(//*[@class='table'])[2]/tbody/tr[" + i + "]/td[1]/input"));
            TaskNames.add(rowElement.getAttribute("value"));
        }
    }

    public void TableData(WebElement tableElement) throws InterruptedException {
        rowElements = tableElement.findElements(By.xpath(".//tr"));
        Thread.sleep(500);
        ArrayList<String> columnNames = new ArrayList<String>();
        List<WebElement> headerElements = rowElements.get(0).findElements(By.xpath(".//th"));
        for (WebElement headerElement : headerElements) {
            columnNames.add(headerElement.getText());
        }
        for (WebElement rowElement : rowElements) {
            HashMap<String, WebElement> row = new HashMap<String, WebElement>();
            int columnIndex = 0;
            List<WebElement> cellElements = rowElement.findElements(By.xpath("//tr[@ng-click='vm.selectResourceRow(resource)']/td"));
            for (WebElement cellElement : cellElements) {
                row.put(columnNames.get(columnIndex), cellElement);
                columnIndex++;
            }
            userTable.add(row);

        }
    }

    public static boolean nameListEquals(List<String> list1, List<String> list2) {
        if (list1.size() != list2.size())
            return true;
        for (String s : list1) {
            if (!list2.contains(s))
                return true;
        }
        return false;
    }

    public void projectPlanDetails() throws InterruptedException {
        Actions.waitUntilElementNotPresent(resourceSavedMessage);
        dropDownSelection("taskTypeId", pTaskType);
        dropDownSelection("sowActivityId0", pActivity);
        dropDownSelection("parentTaskId", pParentTask);
        dropDownSelection("predecessorTaskId", pPredecessorTaskId);
//        Actions.execJavascript("arguments[0].click();", assignedResourceview);
        assignedResourceview.click();
//        Actions.execJavascript("arguments[0].click();", pTaskResourceAssigned);
        pTaskResourceAssigned.click();
//        Actions.execJavascript("arguments[0].click();", taskResourcePopup);
        taskResourcePopup.click();
//        Actions.execJavascript("arguments[0].click();", projectPlanSave);
        projectPlanSave.click();

    }
}
