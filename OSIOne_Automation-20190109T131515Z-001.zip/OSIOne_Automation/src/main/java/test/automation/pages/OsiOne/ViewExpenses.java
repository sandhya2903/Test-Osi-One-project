package test.automation.pages.OsiOne;

import org.apache.commons.collections.Buffer;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.Link;
import ru.yandex.qatools.htmlelements.element.TextBlock;
import test.automation.framework.Config;
import test.automation.framework.Page;

/**
 * Created by amolleti on 10/1/2018.
 */
public class ViewExpenses extends Page {

    public static final String URL = Config.getUrl() + "/a5/#/expenses/view-expenses";
    public static final By VERIFY_BY = By.className("pull-left");

    @Name("Open Button")
    @FindBy(id = "btn-open")
    public static Button open;

    @Name("Submitted Button")
    @FindBy(id = "btn-sub")
    public static Button submitted;

    @Name("Approved Button")
    @FindBy(id = "btn-apprv")
    public static Button approved;

    @Name("Rejected Button")
    @FindBy(id = "btn-rej")
    public static Button rejected;

    @Name("Reimbursed Button")
    @FindBy(id = "btn-reimb")
    public static Button reimbursed;

    @Name("All Button")
    @FindBy(id = "btn-all")
    public static Button all;

    @Name("Created Date")
    @FindBy(xpath = "(//*[@col-id=\"submitedDate\"])[2]")
    public static TextBlock createdDate;

    @Name("Statuts")
    @FindBy(xpath = "(//*[@col-id=\"status\"])[2]")
    public static TextBlock status;

    @Name("Row id")
    @FindBy(xpath = "(//*[@row-index='0'])[3]")
    public static TextBlock row;

    @Name("Logout")
    @FindBy(xpath = "//*[contains(text(),\"Logout\")]")
    public static Link logout;
}
