package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.TextInput;
import test.automation.framework.Actions;
import test.automation.framework.Config;
import test.automation.framework.Page;
import test.automation.models.User;

/**
 * Created by amolleti on 10/4/2018.
 */
public class LogoutPage extends Page {
    public static final String URL = Config.getUrl() + "/a1/#/logout";
    public static final By VERIFY_BY = By.id("login-form");

    @Name("LoginSteps Button")
    @FindBy(xpath = "//button[contains(text(),'Sign in')]")
    public static Button loginButton;

    @Name("Email")
    @FindBy(xpath = "//input[@id='login-username']")
    public static TextInput email;

    @Name("Password")
    @FindBy(xpath = "//input[@id='login-password']")
    public static TextInput password;

    public static void signIn(User user) throws InterruptedException {
        email.sendKeys(user.getLoginEmail());
        password.sendKeys(user.getPwd());
        Actions.waitUntilElementPresent(loginButton);
        Actions.execJavascript("arguments[0].click()", loginButton);
    }
}
