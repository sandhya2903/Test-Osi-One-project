package test.automation.pages.OsiOne;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.Link;
import ru.yandex.qatools.htmlelements.element.TextBlock;
import test.automation.framework.Actions;
import test.automation.framework.Browser;
import test.automation.framework.Config;
import test.automation.framework.Page;

import java.util.List;


/**
 * Created by vemanepalli on 24-Sep-18.
 */
public class LeaveApprovalsPage extends Page {
    public static final String URL = Config.getUrl() + "/a5/#/leaves/approve-leave";
    public static final By VERIFY_BY = By.xpath("//h1[contains(text(),'Leave For Approval')]");
    public static List<WebElement> leaveTableData;
    public static WebElement leaveID;
    public static String reasonForRejection = "Wrong date leave submitted";

    @Name("Approve/ Reject Buttons")
    @FindBy(xpath = "//a[contains(text(),'Approve / Reject')]")
    public static Link approveRejectButtons;

    @Name("table data")
    //@FindBy(xpath = "//table[@class='table table-striped table-sm']/tbody")
    @FindBy(xpath = "//table[@class='table table-striped']/tbody/tr")
    public static List<WebElement> tableDataInfo;

    @Name("Leave Summary Text")
    @FindBy(xpath = "//h1[contains(text(),'Leaves Summary')]")
    public static WebElement leaveSummaryText;

    @Name("Approve Button")
    @FindBy(xpath = "//button[contains(text(),'Approve')]")
    public static Button approveButton;

    @Name("Confirmation Yes Button")
    @FindBy(xpath = "(//button[contains(text(),'Yes')])[1]")
    public static Button confirmYesButton;

    @Name("Cancel Confirmation Yest Button")
    @FindBy(xpath = "(//button[contains(text(),'Yes')])[3]")
    public static Button cancelConfirmationYesButton;

    @Name("Leave Request Cancelled Confirmation Message")
    @FindBy(xpath = "//*[contains(text(),'Leave Request Cancelled')]")
    public static WebElement leaveRequestCancelledMessage;

    @Name("Leave Request Approved Message")
    @FindBy(xpath = "//*[contains(text(),'Leave Request Approved')]")
    public static TextBlock approvedSuccessMessage;

    @Name("Reject Button")
    @FindBy(xpath = "//button[contains(text(),'Reject')]")
    public static Button rejectButton;

    @Name("Reject Reason Message")
    @FindBy(name = "rejectReason")
    public static TextBlock rejectReasonTextBox;

    @Name("Yes Button on Reject Reason Window")
    @FindBy(xpath = "(//button[contains(text(),'Yes')])[2]")
    public static Button rejectYesConfirmationButton;

    @Name("Leave Request Rejected Message")
    @FindBy(xpath = "//*[contains(text(),'Leave Request Rejected')]")
    public static TextBlock rejectedSuccessMessage;

    @Name("Logout")
    @FindBy(xpath = "//a[contains(text(),'Logout')]")
    public static Link logoutButton;

    @Name("Cancel Request Button")
    @FindBy(xpath = "//a[contains(text(),'Cancel Request')]")
    public static Link cancelRequestLinkButton;

    @Name("Cancel Leave Button")
    @FindBy(xpath = "//button[contains(text(),'Cancel Leave')]")
    public static Button cancelLeaveButton;


    public static void leaveApproveReject(List<WebElement> tableDataInfo) throws InterruptedException {
//        leaveTableData = tableDataInfo.findElements(By.tagName("tr"));
        for (WebElement tr_element : tableDataInfo) {
            if (tr_element.getText().contains(NewLeaveRequestPage.leaveIdText)) {
                Actions.doubleClick(tr_element);
                approveButton.click();
                Thread.sleep(2000);
                Actions.waitUntil(() -> confirmYesButton.isDisplayed(), 2000);
                Actions.execJavascript("arguments[0].click();", confirmYesButton);
            }
            //approveRejectButtons.click();

            //confirmYesButton.click();
        }
    }

    public static void SuccessMessage() throws InterruptedException {
        Assert.assertTrue("Leave Request Not Approved Successfully", approvedSuccessMessage.isDisplayed());
        Browser.getDriver().navigate().refresh();
        logoutButton.click();
    }

    public static void leaveRejectLinkButton(List<WebElement> tableDataInfo) throws InterruptedException {
//        leaveTableData = tableDataInfo.findElements(By.tagName("tr"));
        for (WebElement tr_element : tableDataInfo) {
            if (tr_element.getText().contains(NewLeaveRequestPage.leaveIdText)) {
                Actions.doubleClick(tr_element);
                // approveRejectButtons.click();
                Thread.sleep(2000);
                Actions.waitUntil(() -> leaveSummaryText.isDisplayed(), 3000);
            }

        }
    }


    public static void leaveRejectedOperations() throws InterruptedException {
        rejectButton.click();
        rejectReasonTextBox.sendKeys(reasonForRejection);
        // rejectYesConfirmationButton.click();
        Actions.execJavascript("arguments[0].click();", rejectYesConfirmationButton);


    }

    public static void leaveRejectSuccessMessage() {
        Assert.assertTrue("Leave Request Not Reject Successfully", rejectedSuccessMessage.isDisplayed());
        Browser.getDriver().navigate().refresh();
        logoutButton.click();
    }

    public static void cancelRequestOpetation() throws InterruptedException {
        cancelRequestLinkButton.click();
        Actions.execJavascript("arguments[0].click();", cancelLeaveButton);
        Actions.waitUntil(() -> cancelConfirmationYesButton.isDisplayed(), 2000);
        Actions.execJavascript("arguments[0].click();", cancelConfirmationYesButton);
        //Assert.assertTrue("Leave Request Rejected not sucessfully", rejectedSuccessMessage.isDisplayed());
        Thread.sleep(2000);
        Browser.getDriver().navigate().refresh();
        logoutButton.click();

    }
}
