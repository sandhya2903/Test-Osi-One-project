package test.automation.pages.OsiOne;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.*;
import test.automation.framework.*;
import test.automation.framework.Actions;
import test.automation.models.Customers;
//import org.openqa.selenium.interactions.Actions;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by vemanepalli on 07-Sep-18.
 */
public class AddCustomerPage extends Page {
    public static final String URL = Config.getUrl() + "/a1/#/addCustomer";
    public static final By VERIFY_BY = By.id("custContainers");

    public static String custName;
    public static String websiteName;
    public static String regionName;
    public static String timeZoneName;
    public static String acctManager;
    public static String fullName;
    public static WebElement empNames;
    public static String salesPersonData;
    public static String salesFullName;
    public static WebElement empNames1;
    public static String getSourcedFrom;
    public static String paymentTermsValue;
    public static String invoiceNotesValue;
    public static String taxRateValue;
    public static String lateFeeTermsValue;
    public static String currencyValue;
    public static String businessDomainValue;
    public static String addressline1Value;
    public static String addressline2Value;
    public static String countryValue;
    public static String stateValue;
    public static String cityValue;
    public static String zipcodeValue;
    public static String addContactNameValue;
    public static String mobileNumberValue;
    public static String emailAddressValue;
    public static String alternateMobileNumberValue;

    @Name("Customer Name")
    @FindBy(id = "customerName")
    public static TextInput customerName;

    @Name("Customer Long Name")
    @FindBy(id = "customerLongName")
    public static TextInput customerLongName;

    @Name("Website")
    @FindBy(id = "custUrl")
    public static TextInput website;

    @Name("Region")
    @FindBy(id = "custRegion")
    public static Select region;

    @Name("Timezone")
    @FindBy(id = "custTimezone")
    public static Select timezone;

    @Name("Account Manager")
    @FindBy(id = "accountManager")
    public static TextInput accountManager;

    @Name("Employee List")
    @FindBy(className = "supervisor-option")
    public static List<WebElement> empList;

    @Name("Sales Person Name")
    @FindBy(id = "salesRepName")
    public static TextInput salesPersonName;

    @Name("Customer Sourced From")
    @FindBy(xpath = "(//*[@id='customerSourcedFrom'])[1]")
    public static Select customerSourcedFrom;

    @Name("Payment Terms")
    @FindBy(xpath = "(//*[@id='customerSourcedFrom'])[2]")
    public static Select paymentTerms;

    @Name("Invoice Template")
    @FindBy(id = "invoiceTemplateName")
    public static Select invoiceTemplate;

    @Name("Invoice Notes")
    @FindBy(id = "ccTxtArea")
    public static TextBlock invoiceNotes;

    @Name("Tax Rate")
    @FindBy(xpath = "(//*[@id='customerSourcedFrom'])[3]")
    public static Select taxRate;

    @Name("Late fee Terms")
    @FindBy(xpath = "(//*[@id='customerSourcedFrom'])[4]")
    public static Select lateFeeTerms;

    @Name("Currency")
    @FindBy(xpath = "(//*[@id='currency'])[1]")
    public static Select currency;

    @Name("Business Domain")
    @FindBy(xpath = "(//*[@id='currency'])[2]")
    public static Select businessDomain;

    @Name("Is Active")
    @FindBy(id = "isActive")
    public CheckBox isActive;

    @Name("Upload Image")
    @FindBy(xpath = "//img[@class='img-fluid']")
    public static WebElement uploadImage;

    @Name("Add Edit Contact Details Button")
    @FindBy(xpath = "//button[@ng-click='vm.openAddressContacts();']")
    public static Button buttonIcon;

    @Name("Address Line 1")
    @FindBy(id = "addressLine1")
    public static TextBlock addressline1;

    @Name("Address Line 2")
    @FindBy(id = "addressLine2")
    public static TextBlock addressLine2;

    @Name("Country")
    @FindBy(id = "country")
    public static Select country;

    @Name("State")
    @FindBy(id = "state ")
    public static Select state;

    @Name("City")
    @FindBy(id = "city ")
    public static TextInput city;

    @Name("Zipcode")
    @FindBy(id = "zipcode ")
    public static TextInput zipcode;

    @Name("Add Button")
    @FindBy(xpath = "(//button[contains(text(),'Add')])[2]")
    public static Button addButton;

    @Name("Invoice Address")
    @FindBy(xpath = "//*[contains(text(),'Invoice Address')]")
    public static Radio invoiceAddress;

    @Name("Invoice Address Label Text")
    @FindBy(xpath= "//input[@ng-model='vm.customerInfo.customerAddress.addressType']")
    public static WebElement invoiceAddressLabelText;

    @Name("Communication Address Label Text")
    @FindBy(xpath= "(//input[@ng-model='vm.customerInfo.customerAddress.addressType'])[2]")
    public static WebElement communicationAddressLabelText;

    @Name("Primary CheckBox")
    @FindBy(xpath = "//*[@ng-model=\"vm.customerInfo.customerAddress.isPrimaryAddress\"]")
    public static CheckBox primaryCheckbox;

    @Name("Communication Address")
    @FindBy(xpath = "(//*[@ng-model='vm.customerInfo.customerAddress.addressType'])[2]")
    public static Radio communicationAddress;

    @Name("Edit Invoice Address")
    @FindBy(xpath = "(//span[@ng-click='vm.editAddress($index)'])[1]")
    public static Button editInvoiceAddress;

    @Name("Edit Communication Address")
    @FindBy(xpath = "(//span[@ng-click='vm.editAddress($index)'])[2]")
    public static Button editCommunicationAddress;

    @Name("Edit Contact Details")
    @FindBy(xpath = "//span[@ng-click='vm.editContact($index)']")
    public static Button editContactDetails;

    @Name("Close Button")
    @FindBy(xpath = "(//button[@class='close modelCloseButton'])[10]")
    public static Button closeButton;

    @Name("Contacts Close Button")
    @FindBy(xpath = "//*[@ng-click=\"vm.resetData('contact');\"]")
    public static Button contactsCloseButton;

    @Name("Contacts")
    @FindBy(xpath = "//a[contains(text(), 'Contacts')]")
    public static Link contacts;

    @Name("Address")
    @FindBy(xpath = "//a[contains(text(), 'Address')]")
    public static Link address;

    @Name("Contact Name")
    @FindBy(id = "contactName")
    public static TextInput addContactName;

    @Name("Contact Number")
    @FindBy(id = "phone")
    public static TextInput contactNumber;

    @Name("Email Address")
    @FindBy(id = "email")
    public static TextBlock emailAddress;

    @Name("Alternate Contact Number")
    @FindBy(id = "altPhone")
    public static TextInput alternateContactNumber;

    @Name("Add Contacts Button")
    @FindBy(xpath = "(//button[contains(text(), 'Add')])[1]")
    public static TextInput addContactsButton;

    @Name("Employee List Popup")
    @FindBy(xpath = "//label[@class='control-label no-padding pull-right']")
    public static TextBlock empListLabel;

    @Name("Save Button")
    @FindBy(xpath = "//button[contains(text(), 'Save')]")
    public static Button saveButton;

    @Name("Customer Saved Message")
    @FindBy(xpath = "//div[contains(text(),'Customer saved successfully')]")
    public static WebElement customerSuccessMessage;

    public static void addCustomerDetails(Customers customers) throws InterruptedException {
        custName = Util.getCustomerName(5);
        customerName.sendKeys(custName);
        customerLongName.sendKeys(custName);
        websiteName = Util.getRandomWebsite(custName);
        website.sendKeys(websiteName);
        regionName = customers.getRegion();
        region.selectByVisibleText(regionName);
        timeZoneName = customers.getTimeZone();
        timezone.selectByVisibleText(timeZoneName);
        acctManager = Util.getRandomFirstName();
        accountManager.sendKeys(acctManager);
        accountManager.sendKeys(Keys.TAB);
        Thread.sleep(1000);
//        Actions.waitUntil(() -> empListLabel.isDisplayed(), 2000);
        fullName = getAccuontManagerDetailsNames(acctManager);
        empNames = empList.stream().filter(a -> a.getText().equals(fullName)).collect(Collectors.toList()).get(0);
//        org.openqa.selenium.interactions.Actions actions = new org.openqa.selenium.interactions.Actions(Browser.getDriver());
        Actions.doubleClick(empNames);
        Thread.sleep(1000);
//        Actions.waitUntil(() -> !empListLabel.isDisplayed(), 1000);
        salesPersonData = Util.getRandomFirstName();
        salesPersonName.sendKeys(salesPersonData);
        salesPersonName.sendKeys(Keys.TAB);
//        Actions.waitUntil(() -> empListLabel.isDisplayed(), 2000);
        Thread.sleep(1000);
        salesFullName = getAccuontManagerDetailsNames(salesPersonData);
        empNames1 = empList.stream().filter(a -> a.getText().equals(salesFullName)).collect(Collectors.toList()).get(0);
//        org.openqa.selenium.interactions.Actions a = new org.openqa.selenium.interactions.Actions(Browser.getDriver());
        Actions.doubleClick(empNames1);
        Thread.sleep(1000);
//        Actions.waitUntil(() -> !empListLabel.isDisplayed(), 1000);
        getSourcedFrom = customers.getCustomerSourcedFrom();
        customerSourcedFrom.selectByVisibleText(getSourcedFrom);
        paymentTermsValue = customers.getPaymentTerms();
        paymentTerms.selectByVisibleText(paymentTermsValue);
        Actions.execJavascript("arguments[0].scrollIntoView();", invoiceNotes);
        invoiceNotesValue = customers.getInvoiceNotes();
        invoiceNotes.sendKeys(invoiceNotesValue);
        taxRateValue = customers.getTaxRate();
        taxRate.selectByVisibleText(taxRateValue);
        lateFeeTermsValue = customers.getLateFeeTerms();
        lateFeeTerms.selectByVisibleText(lateFeeTermsValue);
        currencyValue = customers.getCurrency();
        currency.selectByVisibleText(currencyValue);
        businessDomainValue = customers.getBusinessDomain();
        businessDomain.selectByVisibleText(businessDomainValue);
    }

    public static void addAdressDetails(Customers customers) throws InterruptedException {
        buttonIcon.click();
        Actions.waitUntil(() -> addressline1.isDisplayed(), 2000);
        if (customers.getType().equals("CommunicationAddress")) {
            communicationAddress.click();
        }
        addressline1Value = customers.getAddressLine1();
        addressline2Value =  customers.getAddressLine2();
        countryValue = customers.getCountry();
        stateValue = customers.getState();
        cityValue = customers.getCity();
        zipcodeValue = customers.getZipcode();
        addressline1.sendKeys(addressline1Value);
        addressLine2.sendKeys(addressline2Value);
        country.selectByVisibleText(countryValue);
        state.selectByVisibleText(stateValue);
        city.sendKeys(cityValue);
        zipcode.sendKeys(zipcodeValue);
        addButton.click();
        Actions.waitUntil(() -> !addButton.isDisplayed(), 2000);
    }

    public static void addContactsDetails(Customers customers) throws InterruptedException {
        contacts.click();
        Actions.waitUntil(() -> buttonIcon.isDisplayed(), 2000);
        buttonIcon.click();
        Actions.waitUntil(() -> contactNumber.isDisplayed(), 2000);
        addContactNameValue = Util.getCustomerName(5);
        addContactName.sendKeys((addContactNameValue));
        mobileNumberValue = Util.getRandomMobleNumber();
        contactNumber.sendKeys(mobileNumberValue);
        emailAddressValue = Util.generateRandomEmail(8);
        emailAddress.sendKeys(emailAddressValue);
        alternateMobileNumberValue = Util.getRandomMobleNumber();
        alternateContactNumber.sendKeys(alternateMobileNumberValue);
        addContactsButton.click();
        Actions.waitUntil(() -> !addContactsButton.isDisplayed(), 1000);
    }

    public static String getAccuontManagerDetailsNames(String names) {
        String fullName = null;
        switch (names) {
            case "VENKATE":
                fullName = "Venkatesh Manepalli";
                break;
            case "PARAM":
                fullName = "Parameshwar Reddy Pentaparthy";
                break;
            case "AVINA":
                fullName = "Avinash Gadamsetty";
                break;
            case "DURG":
                fullName = "Durgadevi Cherukuri";
                break;
            case "ABHILAS":
                fullName = "Abhilash Molleti";
                break;
        }
        return fullName;
    }

}
